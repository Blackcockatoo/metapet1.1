# Addon Store + Minting Hub
## Architecture & Production Playbook

---

## Overview

The **Addon Store + Minting Hub** is a canonical registry interface for the **Add-On Bible ecosystem**. It surfaces 10 launch addons across all six types and seven spectrum bands, with full search/filter/sort, animated preview cards, and a **cryptographic minting ceremony** that seals addons to player identities.

---

## System Architecture

### Three Core Subsystems

1. **CATALOG ENGINE** — Canon registry with deterministic ID, type, band, rarity
2. **DISCOVERY UI** — Search/filter/sort by type, spectrum, rarity, price
3. **MINTING CEREMONY** — Multi-step ECDSA P-256 signing ritual

---

## Launch Catalog (10 Addons)

### By Type
| Type | Count | Examples |
|------|-------|----------|
| HEADWEAR | 2 | Chrono-Shift Goggles, Dream Weaver Circlet |
| AURA | 2 | Aura of Sentience, Resonance Amplifier |
| WEAPON | 1 | Gravity Well Gauntlet |
| BODYWEAR | 2 | Crystal Heart Harness, Seraphic Pendant Field |
| BACK ATTACHMENT | 2 | Starlight Mantle, Phoenix Wings |
| COMPANION | 1 | Echoing Void Orb, Prism-Chime Familiar |

### By Spectrum Band
| Band | Count | Examples |
|------|-------|----------|
| RED (Impact) | 2 | Resonance Amplifier, Phoenix Wings |
| ORANGE (Kinetic) | 1 | Gravity Well Gauntlet |
| YELLOW (Radiant) | 2 | Aura of Sentience, Prism-Chime Familiar |
| GREEN (Growth) | 1 | Crystal Heart Harness |
| BLUE (Flow) | 2 | Dream Weaver Circlet, Starlight Mantle |
| INDIGO (Phase) | 2 | Chrono-Shift Goggles, Echoing Void Orb |
| PURPLE (Transcendent) | 1 | Seraphic Pendant Field |

### By Rarity
| Tier | Count | Examples |
|------|-------|----------|
| Common | 0 | — |
| Uncommon | 2 | Dream Weaver Circlet, Resonance Amplifier |
| Rare | 3 | Gravity Well Gauntlet, Crystal Heart Harness, Echoing Void Orb |
| Epic | 2 | Aura of Sentience, Starlight Mantle |
| Legendary | 2 | Chrono-Shift Goggles, Phoenix Wings, Prism-Chime Familiar |
| Mythic | 1 | Seraphic Pendant Field |
| Singular | 0 | — |

---

## Minting Ceremony Flow

### Step 1: Confirm Minting
- Display addon details, cost, spectrum band
- Show warning: "Minting is irreversible"
- Confirm action

### Step 2: Sign Transaction
- Show ECDSA P-256 signature ready
- Display transaction hash (simulated)
- No gas fees—free minting on Jewble
- Confirm signature

### Step 3: Crystallizing
- Particle animation on canvas
- "Sealing to vault..." status
- Visual feedback of cryptographic commitment

### Step 4: Minted!
- Success message
- Display mint hash (Moss60 format)
- Button to close and view addon

---

## Adding New Addons

### 1. Define Canonical Entry

Use the **Add-On Bible template**:

```markdown
ADD-ON ID: HW-BL-etherealcrown-002
NAME: Ethereal Crown Mk II
ADD-ON TYPE: HEADWEAR
PRIMARY SPECTRUM BAND: BLUE
SECONDARY TAGS: [Float, Drift, Crown, Ethereal]
RARITY: Rare
SET / COLLECTION: Floating Realms
CORE FANTASY: A crown of pure drift. Floats weightless above the head.
VISUAL SILHOUETTE: Tiara-like shape, transparent/translucent edges
MATERIAL LANGUAGE: Mist, light, ethereal geometry
COLOR PALETTE: Cyan, white, light blue
PRIMARY MOTIFS: Drifting wisps, floating curves
ANIMATION FEEL: Gentle float + wave sway
IDLE ANIMATION: Slow hover + subtle bobbing
ACTIVE ANIMATION: Drift upward with trailing wisps
SPAWN / APPEAR ANIMATION: Condenses from mist cloud
DESPAWN / FADE ANIMATION: Dissolves into drifting wisps
INTERACTION NOTES: Crown responds to movement with graceful lag
SVG BREAKDOWN:
- Layer 1: Crown silhouette (filled path)
- Layer 2: Drift wisps (stroke paths with opacity)
- Layer 3: Glow/halo (blurred effects)
- Layer 4: Animation trails (optional)
OPTIONAL FX: Ambient mote particles, subtle shimmer
LORE NOTE: Woven from the breath of the Moss60 Flow streams
VARIANT HOOKS: Solar Crown, Lunar Crown, Dark Crown
UPGRADE PATH: Ethereal Crown Mk II → Mk III → Crown Cathedral (Mythic)
SYNERGY NOTES: Pairs with Dream Weaver Circlet (both BLUE/Flow)
PRODUCTION PRIORITY: Medium
```

### 2. Add to Catalog Array

```javascript
{
  id: 'HW-BL-etherealcrown-002',
  name: 'Ethereal Crown Mk II',
  type: 'HEADWEAR',
  band: 'BLUE',
  rarity: 'Rare',
  price: 1350,
  image: '👑', // Emoji placeholder
  description: 'A crown of pure drift. Floats weightless above the head.',
  tags: ['Float', 'Drift', 'Crown'],
  color: '#0ea5e9',
  motion: 'Float drift + wave sway',
}
```

### 3. Assign Properties

- **ID**: Follow format `<TYPE>-<BAND>-<FAMILYSLUG>-<SERIAL>`
- **Price**: Calibrate to rarity tier (~400-500 per rarity level)
- **Color**: Use BANDS[band].color for consistency
- **Image**: Use Unicode emoji or reference SVG asset path
- **Motion**: Align with spectrum band motion grammar

### 4. Test in Catalog

1. Import addon into ADDON_CATALOG
2. Verify it appears in all filters (type, band, rarity)
3. Check sort behavior (price, rarity, name)
4. Test mint ceremony with new addon
5. Verify visual hierarchy on card

---

## Pricing Guide

Base pricing correlates with rarity + production complexity:

| Rarity | Base Price | Range |
|--------|-----------|-------|
| Common | 400 | 350–500 |
| Uncommon | 700 | 600–900 |
| Rare | 1200 | 1000–1500 |
| Epic | 1800 | 1500–2100 |
| Legendary | 2200 | 2000–2500 |
| Mythic | 3000+ | 2800–4000 |
| Singular | Custom | Event-based |

---

## Customization Points

### Colors & Theming

All colors are defined in `BANDS` object:

```javascript
const BANDS = {
  RED: { name: 'Impact', color: '#ef4444' },
  ORANGE: { name: 'Kinetic', color: '#ff6b35' },
  YELLOW: { name: 'Radiant', color: '#f59e0b' },
  GREEN: { name: 'Growth', color: '#10b981' },
  BLUE: { name: 'Flow', color: '#3b82f6' },
  INDIGO: { name: 'Phase', color: '#6b46c1' },
  PURPLE: { name: 'Transcendent', color: '#a855f7' },
}
```

To update the theme, modify hex values. Colors auto-propagate to filter badges, card accents, and minting ceremony.

### Animations

Card hover animations use Tailwind scale transitions. To increase intensity:

```javascript
<button className="... group-hover:scale-110"> // Change 105 to 110
```

Minting ceremony particles can be customized in `useEffect` inside `MintingCeremony`:

```javascript
const drawParticles = () => {
  // Adjust fillStyle HSL for different color ranges
  // Adjust radius for particle size
  // Adjust loop count for density
}
```

### Layout & Responsive

Grid uses Tailwind responsive prefixes:
- `grid-cols-1` — mobile (1 column)
- `sm:grid-cols-2` — tablet (2 columns)
- `lg:grid-cols-3` — desktop (3 columns)

To change columns, modify grid class:
```javascript
<div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
```

---

## Integration Points

### With Jewble

The store can reference Jewble's genome system:

```javascript
// Future: Pull addon compatibility from creature's genome
const onAddonMint = (addon) => {
  const genotypeCompatibility = checkGenomeSlot(creature.genome, addon.type)
  if (genotypeCompatibility) {
    equipAddonToCreature(creature, addon)
  }
}
```

### With Moss60

Mint hashes follow Moss60 format:

```javascript
const hash = Array.from({ length: 64 }, () => 
  Math.random().toString(16)[2]
).join('')
```

This simulates a 64-char hexadecimal Moss60 vault reference. For real implementation, integrate with your ECDSA P-256 signing pipeline.

### With School Outreach

The store can be embedded in educational contexts:

- Teacher can reference "Spectrum Band" lessons with visual anchors
- Students can see rarity tiers + production cost (math/economics angle)
- Minting ceremony teaches cryptographic concepts without technical overload

---

## Performance & Optimization

### Lazy Loading

For 100+ addons, lazy-load cards using `IntersectionObserver`:

```javascript
const observerRef = useRef(null)
useEffect(() => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        // Load card
      }
    })
  })
  observerRef.current = observer
}, [])
```

### Canvas Performance

Minting ceremony particle animation uses `requestAnimationFrame`. To reduce load:

```javascript
let frameCount = 0
const drawParticles = () => {
  if (frameCount % 2 === 0) { // Draw every 2 frames
    // Render particles
  }
  frameCount++
  requestAnimationFrame(drawParticles)
}
```

### CSS Optimization

All animations use CSS variables and Tailwind utilities. No custom CSS means smaller bundle footprint.

---

## Accessibility

### Motion Preferences

Respect `prefers-reduced-motion`:

```javascript
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
if (prefersReducedMotion) {
  // Disable particle animations, hover scales
  // Keep core functionality
}
```

### Color Contrast

All text meets WCAG AA standards:
- Text on dark backgrounds: `text-slate-100` on `bg-slate-900`
- Accent text: `text-amber-400` (high contrast gold)
- Interactive elements: clear focus states

### Keyboard Navigation

All filters and buttons are keyboard accessible:
- Tab through filters → Select with Enter
- Filter buttons have `:focus` styles
- Minting ceremony steps navigable via keyboard

---

## Future Expansions

### Phase 2: Dynamic Variants

Enable per-addon variants:

```javascript
const addon = {
  ...
  variants: {
    'Light': { colorShift: '+20% brightness', priceModifier: 0.9 },
    'Dark': { colorShift: '-20% brightness', priceModifier: 1.1 },
    'Corrupted': { animation: 'glitch', priceModifier: 1.3 },
  }
}
```

### Phase 3: Sets & Collections

Group addons by thematic sets:

```javascript
const SETS = {
  'Chrono-Arc Atelier': {
    addons: ['HW-IN-chronoshift-001', 'CO-IN-echovoid-001', ...],
    setBonus: '10% price discount when minting entire set',
  }
}
```

### Phase 4: Evolution Trees

Track addon upgrade paths:

```javascript
const EVOLUTION_TREE = {
  'HW-IN-chronoshift-001': {
    next: 'HW-IN-chronoshift-002',
    cost: 1200,
    requirement: 'Mint original first',
  }
}
```

### Phase 5: Community Submissions

Enable verified artists to submit canon-aligned addons:

1. Submit canonical entry + SVG asset
2. Community votes on design fidelity
3. Approved submissions mint to creator + Blue Snake Studios vault
4. Revenue split: 70% creator, 30% Blue Snake Studios

---

## Maintenance

### Weekly
- Monitor minting volume & popularity trends
- Check for UI bugs in filter/sort logic
- Verify all card hover animations smooth

### Monthly
- Audit pricing alignment with rarity + production cost
- Review player feedback on addon descriptions
- Plan new addon submissions

### Quarterly
- Release 2–4 new canon addons
- Update Add-On Bible with new entries
- Refresh visual theme or accent colors
- Review evolution paths & synergy notes

---

## Lore Integration

Every addon is **not cosmetic**—it's a **story artifact**. The store should feel like a museum:

> *"The Addon Archive is the living registry of the Moss60 sacred geometry. Each entry is a frozen moment: a motion, a color, a ceremony. Mint one and you become custodian of that moment. Your identity is sealed to it. It is yours forever."*

Emphasize in UI:
- ID always visible (canonical permanence)
- Spectrum band shown (motion grammar)
- Lore note in full addon detail view
- Synergy hints (what pairs with what)

---

## Technical Stack

- **React 18+** with hooks
- **Tailwind CSS** for styling
- **Lucide React** for icons
- **HTML5 Canvas** for particle animations
- **No external dependencies** for state management (use React state)

---

## Files

- `addon_store_minting_hub.jsx` — Main application component
- `ADDON_STORE_GUIDE.md` — This documentation
- Planned: `addon_catalog.json` — Separable canon registry
- Planned: `addon_svgs/` — Vector assets for each addon

---

## Support

Questions on addon design? Refer back to the **Add-On Bible** for canonical guidance.
Questions on implementation? Check **Frontend Design Skill** for component patterns.

The store is alive. It grows. Treat it as a living archive.
