'use client'

import React, { useState, useEffect, useRef } from 'react'
import { ChevronDown, Search, Sparkles, Zap, Lock, Globe } from 'lucide-react'

const ADDON_CATALOG = [
  {
    id: 'HW-IN-chronoshift-001',
    name: 'Chrono-Shift Goggles',
    type: 'HEADWEAR',
    band: 'INDIGO',
    rarity: 'Legendary',
    price: 2400,
    image: '⏱️',
    description: 'Goggles that warp temporal perception. Twin-lens design with time-offset clarity.',
    tags: ['Temporal', 'Phase', 'Artifact'],
    color: '#6b46c1',
    motion: 'Shimmer + subtle echo duplication',
  },
  {
    id: 'AU-YL-sentience-001',
    name: 'Aura of Sentience',
    type: 'AURA',
    band: 'YELLOW',
    rarity: 'Epic',
    price: 1800,
    image: '✨',
    description: 'A luminous field radiating conscious awareness. Sparkles with purpose.',
    tags: ['Radiant', 'Sentient', 'Glow'],
    color: '#f59e0b',
    motion: 'Sparkle glints + celebration pulses',
  },
  {
    id: 'WP-OR-gravitywell-001',
    name: 'Gravity Well Gauntlet',
    type: 'WEAPON',
    band: 'ORANGE',
    rarity: 'Rare',
    price: 1200,
    image: '⭐',
    description: 'Ceremonial gauntlet that channels kinetic force. Spins with orbital precision.',
    tags: ['Kinetic', 'Weapon', 'Orbital'],
    color: '#ff6b35',
    motion: 'Fast rotate + orbit particles',
  },
  {
    id: 'BW-GN-crystalheart-001',
    name: 'Crystal Heart Harness',
    type: 'BODYWEAR',
    band: 'GREEN',
    rarity: 'Rare',
    price: 1400,
    image: '💎',
    description: 'Living crystalline harness that breathes and blooms. Growth embodied.',
    tags: ['Growth', 'Crystalline', 'Heart'],
    color: '#10b981',
    motion: 'Slow pulse breathing + unfurl reveals',
  },
  {
    id: 'BK-BL-starlight-001',
    name: 'Starlight Mantle',
    type: 'BACK ATTACHMENT',
    band: 'BLUE',
    rarity: 'Epic',
    price: 1900,
    image: '🌙',
    description: 'A flowing cloak of starlit mist. Drifts with cosmic grace.',
    tags: ['Flow', 'Cosmic', 'Drift'],
    color: '#3b82f6',
    motion: 'Float drift + ribbon sway',
  },
  {
    id: 'BK-RD-phoenix-001',
    name: 'Phoenix Wings',
    type: 'BACK ATTACHMENT',
    band: 'RED',
    rarity: 'Legendary',
    price: 2200,
    image: '🔥',
    description: 'Wings of pure impact. Burst with recoil when unfurled.',
    tags: ['Impact', 'Mythic', 'Ascension'],
    color: '#ef4444',
    motion: 'Pulse bursts + shock rings',
  },
  {
    id: 'CO-IN-echovoid-001',
    name: 'Echoing Void Orb',
    type: 'COMPANION',
    band: 'INDIGO',
    rarity: 'Rare',
    price: 1500,
    image: '◯',
    description: 'A temporal companion that listens for cracks in stable time.',
    tags: ['Echo', 'Time', 'Familiar'],
    color: '#6b46c1',
    motion: 'Time-offset pulses + delayed rings',
  },
  {
    id: 'CO-YL-familiar-001',
    name: 'Prism-Chime Familiar',
    type: 'COMPANION',
    band: 'YELLOW',
    rarity: 'Legendary',
    price: 2100,
    image: '🔮',
    description: 'A tiny familiar made of light. Speaks in glints and tones.',
    tags: ['Radiant', 'Sacred', 'Crystal'],
    color: '#fbbf24',
    motion: 'Sparkle flicker + glint sweeps',
  },
  {
    id: 'AU-RD-resonance-001',
    name: 'Resonance Amplifier',
    type: 'AURA',
    band: 'RED',
    rarity: 'Uncommon',
    price: 900,
    image: '📢',
    description: 'An impact field that amplifies force into waves. Rhythmic and decisive.',
    tags: ['Impact', 'Sound', 'Wave'],
    color: '#dc2626',
    motion: 'Pulse hard + burst expansion',
  },
  {
    id: 'HW-BL-dreamweaver-001',
    name: 'Dream Weaver Circlet',
    type: 'HEADWEAR',
    band: 'BLUE',
    rarity: 'Uncommon',
    price: 800,
    image: '🧠',
    description: 'A circlet of flowing consciousness. Weaves streams of thought.',
    tags: ['Flow', 'Dream', 'Mind'],
    color: '#0ea5e9',
    motion: 'Wave ripples + mist currents',
  },
  {
    id: 'BW-PR-seraphic-001',
    name: 'Seraphic Pendant Field',
    type: 'BODYWEAR',
    band: 'PURPLE',
    rarity: 'Mythic',
    price: 3200,
    image: '👼',
    description: 'A transcendent pendant that unfolds sacred geometry. Minimal motion, maximum authority.',
    tags: ['Transcendent', 'Sacred', 'Divine'],
    color: '#a855f7',
    motion: 'Throne-stillness + mandala reveals',
  },
]

const BANDS = {
  RED: { name: 'Impact', color: '#ef4444' },
  ORANGE: { name: 'Kinetic', color: '#ff6b35' },
  YELLOW: { name: 'Radiant', color: '#f59e0b' },
  GREEN: { name: 'Growth', color: '#10b981' },
  BLUE: { name: 'Flow', color: '#3b82f6' },
  INDIGO: { name: 'Phase', color: '#6b46c1' },
  PURPLE: { name: 'Transcendent', color: '#a855f7' },
}

const TYPES = ['HEADWEAR', 'AURA', 'WEAPON', 'BODYWEAR', 'BACK ATTACHMENT', 'COMPANION']
const RARITIES = ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary', 'Mythic', 'Singular']

function MintingCeremony({ addon, onClose }) {
  const [step, setStep] = useState(0)
  const [mintHash, setMintHash] = useState('')
  const canvasRef = useRef(null)

  useEffect(() => {
    if (step === 2) {
      const hash = Array.from({ length: 64 }, () => Math.random().toString(16)[2]).join('')
      setMintHash(hash)

      const canvas = canvasRef.current
      if (!canvas) return
      const ctx = canvas.getContext('2d')
      canvas.width = 400
      canvas.height = 300

      const drawParticles = () => {
        ctx.fillStyle = 'rgba(2, 6, 23, 0.08)'
        ctx.fillRect(0, 0, 400, 300)

        for (let i = 0; i < 12; i++) {
          const x = Math.random() * 400
          const y = Math.random() * 300
          const radius = Math.random() * 2 + 1
          ctx.beginPath()
          ctx.fillStyle = `hsla(${addon.band === 'YELLOW' ? 45 : addon.band === 'PURPLE' ? 280 : 200}, 100%, 60%, ${Math.random() * 0.6})`
          ctx.arc(x, y, radius, 0, Math.PI * 2)
          ctx.fill()
        }
        requestAnimationFrame(drawParticles)
      }
      drawParticles()
    }
  }, [step, addon])

  const steps = [
    {
      title: 'Confirm Minting',
      content: (
        <div className="space-y-4">
          <div className="rounded-lg border border-slate-600/50 bg-slate-900/50 p-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Addon</span>
              <span className="font-mono text-slate-100">{addon.name}</span>
            </div>
            <div className="mt-2 flex items-center justify-between text-sm">
              <span className="text-slate-400">Cost</span>
              <span className="font-mono text-amber-300">{addon.price} MOSS</span>
            </div>
            <div className="mt-2 flex items-center justify-between text-sm">
              <span className="text-slate-400">Spectrum</span>
              <span
                className="inline-block rounded px-2 py-1 text-xs font-bold text-black"
                style={{ backgroundColor: BANDS[addon.band].color }}
              >
                {BANDS[addon.band].name}
              </span>
            </div>
            <div className="mt-2 flex items-center justify-between text-sm">
              <span className="text-slate-400">Rarity</span>
              <span className="font-mono text-slate-200">{addon.rarity}</span>
            </div>
          </div>
          <p className="text-xs leading-relaxed text-slate-400">
            Minting is irreversible. Your addon will be cryptographically sealed to your identity and recorded on the Moss60 prime vault.
          </p>
        </div>
      ),
    },
    {
      title: 'Sign Transaction',
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-center gap-2 rounded-lg border border-purple-500/30 bg-purple-950/20 px-4 py-3">
            <Lock className="h-4 w-4 text-purple-400" />
            <span className="text-sm text-purple-300">ECDSA P-256 Signature Ready</span>
          </div>
          <p className="text-xs leading-relaxed text-slate-400">
            Your wallet will sign this transaction. No gas fees—minting is free on Jewble.
          </p>
          <div className="rounded-lg border border-slate-600/30 bg-slate-800/30 p-3 font-mono text-xs text-slate-300">
            0x{Array.from({ length: 12 }, () => Math.random().toString(16)[2]).join('')}
          </div>
        </div>
      ),
    },
    {
      title: 'Crystallizing...',
      content: (
        <div className="space-y-4">
          <canvas
            ref={canvasRef}
            className="mx-auto h-64 w-full rounded-lg border border-slate-600/30 bg-gradient-to-b from-slate-900 to-black"
          />
          <div className="flex items-center justify-center gap-2">
            <div className="h-2 w-2 animate-pulse rounded-full bg-amber-400" />
            <span className="text-sm text-slate-300">Sealing to vault...</span>
          </div>
        </div>
      ),
    },
    {
      title: 'Minted!',
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-center">
            <div className="text-6xl">{addon.image}</div>
          </div>
          <div className="rounded-lg border border-emerald-500/50 bg-emerald-950/30 p-4 text-center">
            <p className="text-sm font-bold text-emerald-300">Minting Successful</p>
            <p className="mt-2 text-xs text-emerald-200/80">{addon.name} is now bound to your identity.</p>
          </div>
          <div className="space-y-2 rounded-lg border border-slate-600/30 bg-slate-800/30 p-3">
            <p className="text-xs text-slate-400">Mint Hash (Moss60)</p>
            <p className="break-all font-mono text-xs text-amber-300">{mintHash}</p>
          </div>
        </div>
      ),
    },
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-lg border border-slate-600/50 bg-gradient-to-b from-slate-900/95 to-black/95 p-6 shadow-2xl">
        <h2 className="mb-4 text-center font-light tracking-wider text-slate-100">{steps[step].title}</h2>

        {steps[step].content}

        <div className="mt-6 flex gap-3">
          {step > 0 && (
            <button
              onClick={() => setStep(step - 1)}
              className="flex-1 rounded border border-slate-600/50 bg-slate-800/50 py-2 text-sm text-slate-300 transition hover:bg-slate-700/50"
            >
              Back
            </button>
          )}
          {step < steps.length - 1 ? (
            <button
              onClick={() => setStep(step + 1)}
              className="flex-1 rounded bg-amber-500 py-2 text-sm font-bold text-black transition hover:bg-amber-400"
            >
              {step === 0 ? 'Continue' : step === 1 ? 'Sign' : 'Next'}
            </button>
          ) : (
            <button
              onClick={onClose}
              className="flex-1 rounded bg-emerald-600 py-2 text-sm font-bold text-white transition hover:bg-emerald-500"
            >
              Close & View Addon
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

function AddonCard({ addon, onMint }) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative overflow-hidden rounded-lg border border-slate-700/50 bg-gradient-to-br from-slate-900/60 to-slate-950/80 p-4 transition duration-300 hover:border-slate-600"
    >
      <div className="absolute inset-0 opacity-0 transition duration-300 group-hover:opacity-100" style={{ background: `radial-gradient(circle at center, ${addon.color}20, transparent 70%)` }} />

      <div className="relative z-10">
        <div className="flex items-start justify-between">
          <div className="text-4xl">{addon.image}</div>
          <span
            className="inline-block rounded-full px-2 py-1 text-xs font-bold text-black"
            style={{ backgroundColor: BANDS[addon.band].color }}
          >
            {BANDS[addon.band].name}
          </span>
        </div>

        <h3 className="mt-3 font-light tracking-wide text-slate-100">{addon.name}</h3>
        <p className="mt-1 text-xs leading-relaxed text-slate-400">{addon.description}</p>

        <div className="mt-3 flex flex-wrap gap-1">
          {addon.tags.map((tag) => (
            <span key={tag} className="rounded-full bg-slate-800/50 px-2 py-1 text-xs text-slate-300">
              {tag}
            </span>
          ))}
        </div>

        <div className="mt-4 flex items-center justify-between border-t border-slate-700/50 pt-3">
          <div className="flex flex-col">
            <span className="text-xs text-slate-400">Type</span>
            <span className="font-mono text-sm text-slate-200">{addon.type}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs text-slate-400">Rarity</span>
            <span className="font-mono text-sm text-amber-300">{addon.rarity}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs text-slate-400">Price</span>
            <span className="font-mono text-sm text-emerald-400">{addon.price}</span>
          </div>
        </div>

        <button
          onClick={() => onMint(addon)}
          className={`mt-3 w-full rounded bg-amber-500 py-2 text-sm font-bold text-black transition duration-300 hover:bg-amber-400 ${isHovered ? 'scale-105' : ''}`}
        >
          Mint Addon
        </button>
      </div>
    </div>
  )
}

export default function AddonStoreMintingHub() {
  const [search, setSearch] = useState('')
  const [selectedType, setSelectedType] = useState(null)
  const [selectedBand, setSelectedBand] = useState(null)
  const [selectedRarity, setSelectedRarity] = useState(null)
  const [sortBy, setSortBy] = useState('price')
  const [mintingAddon, setMintingAddon] = useState(null)

  const filtered = ADDON_CATALOG.filter((addon) => {
    const matchesSearch = addon.name.toLowerCase().includes(search.toLowerCase()) || addon.id.toLowerCase().includes(search.toLowerCase())
    const matchesType = !selectedType || addon.type === selectedType
    const matchesBand = !selectedBand || addon.band === selectedBand
    const matchesRarity = !selectedRarity || addon.rarity === selectedRarity
    return matchesSearch && matchesType && matchesBand && matchesRarity
  }).sort((a, b) => {
    if (sortBy === 'price') return a.price - b.price
    if (sortBy === 'rarity') return RARITIES.indexOf(a.rarity) - RARITIES.indexOf(b.rarity)
    return a.name.localeCompare(b.name)
  })

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-black text-slate-100">
      {/* Header */}
      <div className="border-b border-slate-800/50 bg-gradient-to-b from-slate-900/50 to-transparent px-6 py-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex items-center gap-3 mb-4">
            <Sparkles className="h-8 w-8 text-amber-400" />
            <h1 className="text-4xl font-light tracking-wider text-slate-100">ADDON STORE</h1>
          </div>
          <p className="text-sm text-slate-400">Browse the Moss60 canonical registry. Mint addons to your cryptographic identity.</p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8">
        {/* Search & Filters */}
        <div className="mb-8 space-y-4 rounded-lg border border-slate-800/50 bg-slate-900/30 p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search addons by name or ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded border border-slate-700/50 bg-slate-800/50 py-2 pl-10 pr-3 text-sm text-slate-100 placeholder-slate-500 transition focus:border-amber-500/50 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {/* Type Filter */}
            <div>
              <label className="mb-2 block text-xs font-bold uppercase text-slate-400">Type</label>
              <select
                value={selectedType || ''}
                onChange={(e) => setSelectedType(e.target.value || null)}
                className="w-full rounded border border-slate-700/50 bg-slate-800/50 py-2 px-3 text-sm text-slate-100 transition focus:border-amber-500/50 focus:outline-none"
              >
                <option value="">All Types</option>
                {TYPES.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>

            {/* Band Filter */}
            <div>
              <label className="mb-2 block text-xs font-bold uppercase text-slate-400">Spectrum</label>
              <select
                value={selectedBand || ''}
                onChange={(e) => setSelectedBand(e.target.value || null)}
                className="w-full rounded border border-slate-700/50 bg-slate-800/50 py-2 px-3 text-sm text-slate-100 transition focus:border-amber-500/50 focus:outline-none"
              >
                <option value="">All Bands</option>
                {Object.entries(BANDS).map(([key, value]) => (
                  <option key={key} value={key}>
                    {value.name} ({key})
                  </option>
                ))}
              </select>
            </div>

            {/* Rarity Filter */}
            <div>
              <label className="mb-2 block text-xs font-bold uppercase text-slate-400">Rarity</label>
              <select
                value={selectedRarity || ''}
                onChange={(e) => setSelectedRarity(e.target.value || null)}
                className="w-full rounded border border-slate-700/50 bg-slate-800/50 py-2 px-3 text-sm text-slate-100 transition focus:border-amber-500/50 focus:outline-none"
              >
                <option value="">All Rarities</option>
                {RARITIES.map((rarity) => (
                  <option key={rarity} value={rarity}>
                    {rarity}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort */}
            <div>
              <label className="mb-2 block text-xs font-bold uppercase text-slate-400">Sort By</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full rounded border border-slate-700/50 bg-slate-800/50 py-2 px-3 text-sm text-slate-100 transition focus:border-amber-500/50 focus:outline-none"
              >
                <option value="price">Price (Low to High)</option>
                <option value="rarity">Rarity (Common to Mythic)</option>
                <option value="name">Name (A to Z)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>{filtered.length} addons found</span>
            {selectedType || selectedBand || selectedRarity || search ? (
              <button
                onClick={() => {
                  setSearch('')
                  setSelectedType(null)
                  setSelectedBand(null)
                  setSelectedRarity(null)
                }}
                className="text-amber-400 transition hover:text-amber-300"
              >
                Clear Filters
              </button>
            ) : null}
          </div>
        </div>

        {/* Addon Grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((addon) => (
              <AddonCard key={addon.id} addon={addon} onMint={setMintingAddon} />
            ))}
          </div>
        ) : (
          <div className="rounded-lg border border-slate-800/50 bg-slate-900/30 p-8 text-center">
            <Zap className="mx-auto h-8 w-8 text-slate-600 mb-2" />
            <p className="text-slate-400">No addons match your filters. Try adjusting your search.</p>
          </div>
        )}

        {/* Stats Footer */}
        <div className="mt-12 rounded-lg border border-slate-800/50 bg-gradient-to-r from-slate-900/30 to-slate-950/50 p-6">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div>
              <p className="text-xs text-slate-400">Total Addons</p>
              <p className="mt-1 font-mono text-xl text-amber-300">{ADDON_CATALOG.length}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Spectrum Bands</p>
              <p className="mt-1 font-mono text-xl text-purple-300">7</p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Rarity Tiers</p>
              <p className="mt-1 font-mono text-xl text-emerald-300">{RARITIES.length}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Type Categories</p>
              <p className="mt-1 font-mono text-xl text-cyan-300">{TYPES.length}</p>
            </div>
          </div>
        </div>

        {/* Info Section */}
        <div className="mt-8 rounded-lg border border-slate-800/50 bg-slate-900/30 p-6">
          <div className="grid gap-6 sm:grid-cols-2">
            <div>
              <h3 className="mb-2 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-200">
                <Globe className="h-4 w-4 text-amber-400" />
                Moss60 Registry
              </h3>
              <p className="text-xs leading-relaxed text-slate-400">
                Every addon is canon-indexed with a deterministic ID, spectrum band assignment, and rarity tier. Browse the full archive and mint directly to your cryptographic identity with zero collection fees.
              </p>
            </div>
            <div>
              <h3 className="mb-2 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-200">
                <Lock className="h-4 w-4 text-emerald-400" />
                Sealed & Bound
              </h3>
              <p className="text-xs leading-relaxed text-slate-400">
                Minted addons are sealed via ECDSA P-256 signature to your Jewble identity. No wallets required—just pure cryptographic ceremony. Your addon is yours forever.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Minting Ceremony Modal */}
      {mintingAddon && <MintingCeremony addon={mintingAddon} onClose={() => setMintingAddon(null)} />}
    </div>
  )
}
