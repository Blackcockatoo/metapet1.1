# Auralia Addon Showcase — Production Grade
## Technical Specifications & Rendering Architecture

---

## Overview

**`auralia_addon_showcase_production.jsx`** is a high-fidelity addon showcase integrating:

1. **Moss60 Cryptographic Seeding** — Auralia's genetic identity system
2. **Four Guardian Forms** — Radiant, Meditation, Sage, Vigilant (form-aware rendering)
3. **Sophisticated Canvas Animation** — Real-time particle, glow, and effect systems
4. **Seven Addon Renderers** — Each with unique motion grammar and visual identity
5. **Interactive Equipping System** — Combine multiple addons, see real-time composition

---

## Architecture

### Core Systems

#### 1. Moss60 Field Generation
```javascript
const initField = (seedName: string) => {
  // RED, BLACK, BLUE: 60-digit base-7 sequences
  // Generates:
  //   - PRNG (pseudo-random number generator)
  //   - Hash function (deterministic)
  //   - Ring/Pulse arrays (genetic markers)
}
```

This matches the original Auralia meta-pet's cryptographic seeding. The field drives particle generation, color selection, and environmental effects.

#### 2. Guardian Forms
Each form has distinct color palettes and visual language:

```javascript
const FORMS = {
  radiant: {
    baseColor: "#2C3E77",      // Deep blue
    primaryGold: "#F4B942",    // Warm gold
    secondaryGold: "#FFD700",  // Bright gold
    tealAccent: "#4ECDC4",     // Seafoam
    eyeColor: "#F4B942",       // Gold eyes
  },
  meditation: {
    baseColor: "#0d1321",      // Nearly black
    primaryGold: "#2DD4BF",    // Cyan
    secondaryGold: "#4ECDC4",  // Teal
    tealAccent: "#1a4d4d",     // Deep teal
    eyeColor: "#2DD4BF",       // Cyan eyes
  },
  sage: {
    baseColor: "#1a1f3a",      // Indigo
    primaryGold: "#FFD700",    // Pure gold
    secondaryGold: "#F4B942",  // Warm gold
    tealAccent: "#4ECDC4",     // Teal
    eyeColor: "#FFD700",       // Gold eyes
  },
  vigilant: {
    baseColor: "#1a1f3a",      // Indigo
    primaryGold: "#FF6B35",    // Fire orange
    secondaryGold: "#FF8C42",  // Light orange
    tealAccent: "#4ECDC4",     // Teal
    eyeColor: "#FF6B35",       // Fire eyes
  },
}
```

Each form reflects a different emotional/energetic state, affecting how addons render.

#### 3. Addon Slot System
Addons are assigned to specific slots that determine attachment point:

```typescript
type AddonSlot = 'head' | 'body' | 'back' | 'aura' | 'companion'

// Example:
{
  id: 'HW-IN-chronoshift-001',
  slot: 'head',           // Attaches to head
  renderFn: renderChronoGoggles,
}
```

Allows accurate positioning and prevents overlapping visual conflicts.

---

## Addon Rendering System

### Seven Custom Render Functions

Each addon has a dedicated renderer implementing:
- **Geometry** — Accurate silhouettes (not approximations)
- **Animation** — Motion grammar matching spectrum band
- **Palette Integration** — Colors respect the Guardian form
- **Layering** — Correct depth ordering
- **Effects** — Glows, particles, trails, shimmer

### 1. Chrono-Shift Goggles
```javascript
function renderChronoGoggles(ctx, x, y, time, form) {
  // Twin lenses with independent shimmer
  const shimmerAlpha = Math.sin(time * 0.004) * 0.3 + 0.5
  
  // Left lens (INDIGO band shimmer)
  ctx.strokeStyle = `rgba(162, 155, 254, ${shimmerAlpha * 0.6})`
  ctx.arc(x - 8, y - 65, 12, ...)
  
  // Right lens (mirrored with phase offset)
  ctx.arc(x + 8, y - 65, 12, ...)
  
  // Bridge connecting both lenses
  ctx.moveTo(x - 6, y - 65)
  ctx.lineTo(x + 6, y - 65)
}
```

**Motion:** Shimmer + subtle echo duplication (INDIGO band)
**Key Feature:** Independent lens glow, time-offset rendering

### 2. Aura of Sentience
```javascript
function renderAuraSentience(ctx, x, y, time, form) {
  // Multiple concentric rings with sparkles
  const glowRadius = 85 + Math.sin(time * 0.002) * 10
  
  // Primary aura ring (breathing)
  ctx.strokeStyle = `rgba(244, 185, 66, ${glowAlpha * 0.6})`
  ctx.arc(x, y, glowRadius, ...)
  
  // Secondary ring (phase offset)
  ctx.arc(x, y, glowRadius + 15, ...)
  
  // 12 orbiting sparkles
  for (let i = 0; i < 12; i++) {
    const angle = (i / 12) * TAU + time * 0.001
    const sparkleAlpha = Math.sin(time * 0.004 + i * 0.5) * 0.5 + 0.5
    // Draw sparkle at computed position
  }
}
```

**Motion:** Celebration pulses + radiant glints (YELLOW band)
**Key Feature:** 12-point radial sparkle field, breathing amplitude

### 3. Starlight Mantle
```javascript
function renderMantleStarlight(ctx, x, y, time, form) {
  // Flowing quadratic curves with star distribution
  const mantleTime = time * 0.0015
  const waveAmp = 20 + Math.sin(mantleTime) * 10
  
  // Left curve with wave animation
  ctx.quadraticCurveTo(
    x - 55, y + 90 + Math.sin(mantleTime) * waveAmp,
    x - 20, y + 150
  )
  
  // Stars scattered along the flow
  for (let i = 0; i < 7; i++) {
    const starX = x - 30 + (i / 7) * 60 + Math.sin(mantleTime + i) * 15
    const starAlpha = 0.6 + Math.sin(mantleTime + i * 0.4) * 0.4
    ctx.arc(starX, starY, 2, ...)
  }
}
```

**Motion:** Drift + ribbon sway (BLUE band)
**Key Feature:** Organic wave motion, trailing mist effect

### 4. Phoenix Wings
```javascript
function renderPhoenixWings(ctx, x, y, time, form) {
  // Bilateral symmetric wings with expansion/contraction
  const wingExpand = Math.sin(wingTime) * 0.15 + 1
  const shockAlpha = Math.sin(wingTime * 2) * 0.4 + 0.5
  
  // Left wing (mirrored with scale transform)
  ctx.save()
  ctx.translate(x - 40, y + 10)
  ctx.scale(-1 * wingExpand, wingExpand)
  ctx.beginPath()
  ctx.moveTo(0, 0)
  ctx.lineTo(-50, -35)
  ctx.quadraticCurveTo(-45, -15, -25, 0)
  ctx.fill()
  ctx.restore()
  
  // Shock rings (expanding + pulsing)
  for (let i = 0; i < 2; i++) {
    const ringRadius = 50 + (i * 20) + Math.sin(wingTime) * 15
    ctx.arc(x, y + 10, ringRadius, ...)
  }
}
```

**Motion:** Pulse bursts + shock rings (RED band)
**Key Feature:** Symmetrical expansion, concentric impulse rings

### 5. Prism-Chime Familiar
```javascript
function renderPrismFamiliar(ctx, x, y, time, form) {
  // Hovering companion with orbital sparkle path
  const familiarTime = time * 0.002
  const fx = x + 65 + Math.sin(familiarTime) * 25
  const fy = y - 25 + Math.cos(familiarTime * 0.7) * 20
  
  // Prism body (triangle)
  ctx.moveTo(fx, fy - 14)
  ctx.lineTo(fx + 12, fy + 8)
  ctx.lineTo(fx - 12, fy + 8)
  
  // Halo ring (rotating reference)
  ctx.arc(fx, fy, 18, ...)
  
  // 6 orbiting sparkles (high frequency rotation)
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * TAU + familiarTime * 1.5
    const sx = fx + Math.cos(angle) * 22
    ctx.arc(sx, sy, 2, ...)
  }
}
```

**Motion:** Sparkle flicker + glint sweeps (YELLOW band)
**Key Feature:** Independent hovering motion, fast orbital sparkle

### 6. Crystal Heart Harness
```javascript
function renderCrystalHarness(ctx, x, y, time, form) {
  // Organic breathing crystalline form
  const crystalTime = time * 0.002
  const breatheScale = 1 + Math.sin(crystalTime) * 0.1
  
  ctx.save()
  ctx.translate(x, y + 20)
  ctx.scale(breatheScale, breatheScale)
  
  // Organic outline (12 points with sine modulation)
  ctx.beginPath()
  for (let i = 0; i < 12; i++) {
    const angle = (i / 12) * TAU
    const r = 18 + Math.sin(crystalTime + angle * 2) * 4
    ctx.lineTo(Math.cos(angle) * r, Math.sin(angle) * r)
  }
  
  // Vein structure (4 radial lines with curve)
  for (let i = 0; i < 4; i++) {
    const angle = (i / 4) * TAU
    ctx.quadraticCurveTo(
      Math.cos(angle) * 15, Math.sin(angle) * 15,
      Math.cos(angle) * 28, Math.sin(angle) * 28
    )
  }
  
  ctx.restore()
}
```

**Motion:** Slow pulse breathing + unfurl reveals (GREEN band)
**Key Feature:** Organic sinusoidal breathing, vein illumination

### 7. Echoing Void Orb
```javascript
function renderEchoOrb(ctx, x, y, time, form) {
  // Temporal delay effect with concentric echo rings
  const echoTime = time * 0.0025
  const ringAlpha = Math.sin(echoTime) * 0.4 + 0.5
  
  // Core orb
  ctx.arc(x + 55, y - 30, 10, ...)
  
  // 3 concentric rings with phase offsets
  for (let i = 0; i < 3; i++) {
    const ringRadius = 20 + i * 12 + Math.sin(echoTime + i * 0.5) * 8
    const alpha = ringAlpha * (0.7 - i * 0.2)
    ctx.arc(x + 55, y - 30, ringRadius, ...)
  }
  
  // Temporal ghost (delayed echo)
  const ghostRadius = 25 + Math.sin(echoTime * 1.5) * 12
  ctx.arc(x + 55, y - 30, ghostRadius, ...)
}
```

**Motion:** Time-offset pulses + delayed rings (INDIGO band)
**Key Feature:** Layered temporal offset, ring phase delay

---

## Animation Framework

### Time-Based Sinusoidal Motion
All animations use trigonometric functions for smooth, predictable motion:

```javascript
// Breathing (slow, relaxed)
const breathe = Math.sin(time * 0.001) * 0.1 + 0.9

// Pulsing (medium, energetic)
const pulse = Math.sin(time * 0.004) * 0.5 + 0.5

// Fast shimmer (rapid, excited)
const shimmer = Math.sin(time * 0.008) * 0.3 + 0.7

// Phase offset (multi-layer)
for (let i = 0; i < count; i++) {
  const phase = Math.sin(time * freq + i * offset)
}
```

### Layering & Depth
Addons render in order to canvas, with proper layering:

```
Background (rings, glow)
  ↓
Head (base geometry)
  ↓
Eyes (directional)
  ↓
Body (base geometry)
  ↓
Back attachments (wings, mantle)
  ↓
Auras (glowing fields)
  ↓
Companions (orbital)
```

---

## Integration Points

### With Auralia Meta-Pet
This showcase can load a full Auralia instance:

```javascript
// Future: Load actual Auralia genome
import AuraliaMetaPet from './AuraliaMetaPet'

export default function FullShowcase() {
  return (
    <>
      <AuraliaMetaPet {...props} />
      <AddonEquippingPanel />
    </>
  )
}
```

### With Jewble Creature System
Persist equipped addons to creature genome:

```javascript
const equipAddon = async (creatureId, addonId) => {
  const creature = await fetchCreature(creatureId)
  creature.addons = [...creature.addons, addonId]
  await saveCreature(creature)
  // Refresh Auralia rendering with new addons
}
```

### With Addon Store
Link to minting directly:

```javascript
<button onClick={() => navigate('/store/' + addon.id)}>
  Mint This Addon
</button>
```

---

## Performance Optimizations

### Canvas Rendering
- **Conditional Rendering:** Only draw equipped addons
- **Layer Caching:** Background rings drawn once per frame, reused
- **Transform Efficiency:** Use `ctx.save()` / `ctx.restore()` for transforms
- **Alpha Channel:** Minimize expensive blend mode changes

### Animation Efficiency
- **Precompute Trigonometry:** Calculate phase offsets outside loops
- **Reduce Particle Count:** Sparkles capped at 12-18 per addon
- **Request Animation Frame:** Native 60 FPS (no setTimeout loops)

### Memory
- **Single Field Instance:** `fieldRef.useRef(initField('AURALIA'))` persists across renders
- **Memoized Renders:** Addon functions accept precomputed values
- **No Heap Allocation in Loop:** All arrays pre-allocated or reused

---

## Customization Guide

### Adding a New Addon Renderer

```javascript
const ADDON_ITEMS = [
  // ... existing addons ...
  {
    id: 'PR-PU-sacred-001',
    name: 'Sacred Mandalic Crown',
    type: 'HEADWEAR',
    slot: 'head',
    band: 'PURPLE',
    rarity: 'Mythic',
    description: '...',
    fullDescription: '...',
    renderFn: renderSacredCrown,  // Your new function
  },
]

function renderSacredCrown(ctx, x, y, time, form) {
  // 1. Design the geometry (SVG reference first)
  // 2. Implement animation (motion grammar for PURPLE: ceremonial rotation)
  // 3. Test with all four Guardian forms
  // 4. Verify no clipping or overlap with body
  
  const crownTime = time * 0.0008  // Slow ceremonial rotation
  const mandalaRotation = crownTime % (Math.PI * 2)
  
  ctx.save()
  ctx.translate(x, y - 70)
  ctx.rotate(mandalaRotation)
  
  // Draw your mandala geometry here
  // Use form.primaryGold and form.tealAccent for colors
  
  ctx.restore()
}
```

### Form-Aware Color Selection
Addons should respect the Guardian form's palette:

```javascript
function renderMyAddon(ctx, x, y, time, form) {
  // GOOD: Use form colors
  ctx.strokeStyle = form.primaryGold
  ctx.fillStyle = form.tealAccent
  
  // BAD: Hardcode colors
  ctx.strokeStyle = '#FFD700'  // Ignores form palette
}
```

### Testing Checklist
1. ✓ Renders with all four Guardian forms
2. ✓ Animates smoothly (60 FPS target)
3. ✓ No clipping with body geometry
4. ✓ Proper depth ordering (doesn't hide head/eyes)
5. ✓ Matches spectrum band motion grammar
6. ✓ Colors from form palette, not hardcoded
7. ✓ Looks good at multiple viewport sizes

---

## Spectrum Band Motion Grammars

When creating new addons, follow these animation patterns:

| Band | Primary Motion | Secondary | Key Frequency |
|------|---|---|---|
| RED | Hard pulse | Burst expand | 0.004–0.008 |
| ORANGE | Fast rotate | Orbit trails | 0.006–0.012 |
| YELLOW | Sparkle glint | Celebration | 0.005–0.010 |
| GREEN | Slow breathe | Unfurl reveal | 0.001–0.003 |
| BLUE | Drift wave | Ribbon sway | 0.0015–0.003 |
| INDIGO | Shimmer echo | Time offset | 0.002–0.005 |
| PURPLE | Ceremonial rotate | Minimal motion | 0.0005–0.0015 |

---

## Known Limitations & Future Work

### Current
- Canvas rendering (not SVG) for performance
- 2D only (no 3D transforms)
- Single creature view (no comparison mode)
- Audio disabled (placeholder for integration)

### Planned
- Integrate full Auralia meta-pet component
- Companion creature spawning (show multiple addons at once)
- Save/share loadouts (screenshot + JSON export)
- Evolution preview (show Mk I → Mk II transformation)
- Community gallery (player addon combinations)

---

## Architecture Diagram

```
AuraliaAddonShowcaseProduction
  ├─ Moss60 Field Generation
  │   └─ initField("AURALIA")
  ├─ Guardian Form Selection
  │   └─ FORMS[form].primaryGold, tealAccent, etc.
  ├─ AuraliaCanvasShowcase (main render)
  │   ├─ Background (rings, breathing glow)
  │   ├─ Core Geometry (head, eyes, body)
  │   ├─ Equipped Addons (renderFn per addon)
  │   └─ requestAnimationFrame loop
  ├─ Carousel Navigation
  │   ├─ Current addon display
  │   ├─ Previous/Next buttons
  │   └─ Indicator dots
  ├─ Form Selector (4 buttons)
  └─ Equipped Addons Panel
      └─ List of active pieces with removal
```

---

## Support & Further Reading

- **Moss60 Theory:** See Add-On Bible (deep-research-report.md)
- **Original Auralia:** AuraliaMetaPet.tsx (uploaded archive)
- **Addon Creation:** ADDON_STORE_GUIDE.md
- **Color Palettes:** FORMS object (top of this file)

---

**Production-ready. Scaling ready. Extensible.**

This showcase sets the standard for how addons should render in the Blue Snake Studios ecosystem.
