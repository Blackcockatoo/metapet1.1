'use client'

import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react'
import { ChevronLeft, ChevronRight, Sparkles, Zap, Lock } from 'lucide-react'

// ===== MOSS60 CORE (from Auralia) =====
const RED = "113031491493585389543778774590997079619617525721567332336510"
const BLACK = "011235831459437077415617853819099875279651673033695493257291"
const BLUE = "012776329785893036118967145479098334781325217074992143965631"

const toDigits = (s: string): number[] => s.split('').map(ch => {
  const d = ch.charCodeAt(0) - 48
  if (d < 0 || d > 9) throw new Error(`non-digit: ${ch}`)
  return d
})

const mix64 = (x0: bigint | number): bigint => {
  let x = BigInt(x0) ^ 0x9E3779B97F4A7C15n
  x ^= x >> 30n; x *= 0xBF58476D1CE4E5B9n
  x ^= x >> 27n; x *= 0x94D049BB133111EBn
  x ^= x >> 31n
  return x & ((1n << 64n) - 1n)
}

const initField = (seedName: string = "AURALIA") => {
  const red = RED, black = BLACK, blue = BLUE
  const r = toDigits(red), k = toDigits(black), b = toDigits(blue)

  const pulse = r.map((rv, i) => (rv ^ k[(i * 7) % 60] ^ b[(i * 13) % 60]) % 10)
  const ring = Array.from({ length: 60 }, (_, i) => (r[i] + k[i] + b[i]) % 10)

  let s0 = mix64(BigInt(seedName.charCodeAt(0)))
  let s1 = mix64(BigInt(seedName.charCodeAt(1)))

  const prng = (): number => {
    let x = s0, y = s1
    s0 = y
    x ^= x << 23n; x ^= x >> 17n; x ^= y ^ (y >> 26n)
    s1 = x
    return Number((s0 + s1) & ((1n << 32n) - 1n)) / 0x100000000
  }

  const hash = (msg: string): bigint => {
    let h = BigInt(seedName.charCodeAt(0))
    for (let i = 0; i < msg.length; i++) {
      h = mix64(h ^ BigInt(msg.charCodeAt(i) + i * 1315423911))
    }
    return h
  }

  return { seed: seedName, ring, pulse, prng, hash }
}

// ===== ADDON CATALOG WITH SLOT SYSTEM =====
const ADDON_ITEMS = [
  {
    id: 'HW-IN-chronoshift-001',
    name: 'Chrono-Shift Goggles',
    type: 'HEADWEAR',
    slot: 'head',
    band: 'INDIGO',
    rarity: 'Legendary',
    description: 'Goggles that warp temporal perception.',
    fullDescription: 'Twin-lens design with time-offset clarity. Worn by architects of temporal ceremony.',
    renderFn: (ctx, x, y, time, form) => renderChronoGoggles(ctx, x, y, time, form),
  },
  {
    id: 'AU-YL-sentience-001',
    name: 'Aura of Sentience',
    type: 'AURA',
    slot: 'aura',
    band: 'YELLOW',
    rarity: 'Epic',
    description: 'Luminous field radiating conscious awareness.',
    fullDescription: 'Sparkles with purpose. The Atelier swears these are made from moments of breakthrough.',
    renderFn: (ctx, x, y, time, form) => renderAuraSentience(ctx, x, y, time, form),
  },
  {
    id: 'BK-BL-starlight-001',
    name: 'Starlight Mantle',
    type: 'BACK ATTACHMENT',
    slot: 'back',
    band: 'BLUE',
    rarity: 'Epic',
    description: 'Flowing cloak of starlit mist.',
    fullDescription: 'Drifts with cosmic grace. Woven from the breath of the Flow streams.',
    renderFn: (ctx, x, y, time, form) => renderMantleStarlight(ctx, x, y, time, form),
  },
  {
    id: 'BK-RD-phoenix-001',
    name: 'Phoenix Wings',
    type: 'BACK ATTACHMENT',
    slot: 'back',
    band: 'RED',
    rarity: 'Legendary',
    description: 'Wings of pure impact.',
    fullDescription: 'Burst with recoil when unfurled. Ascendance incarnate.',
    renderFn: (ctx, x, y, time, form) => renderPhoenixWings(ctx, x, y, time, form),
  },
  {
    id: 'CO-YL-familiar-001',
    name: 'Prism-Chime Familiar',
    type: 'COMPANION',
    slot: 'companion',
    band: 'YELLOW',
    rarity: 'Legendary',
    description: 'Tiny familiar made of light.',
    fullDescription: 'Speaks in glints and tones. Celebrates every moment with chimes.',
    renderFn: (ctx, x, y, time, form) => renderPrismFamiliar(ctx, x, y, time, form),
  },
  {
    id: 'BW-GN-crystalheart-001',
    name: 'Crystal Heart Harness',
    type: 'BODYWEAR',
    slot: 'body',
    band: 'GREEN',
    rarity: 'Rare',
    description: 'Living crystalline harness that breathes.',
    fullDescription: 'Grows with the wearer. Veins illuminate in cascades. Growth embodied.',
    renderFn: (ctx, x, y, time, form) => renderCrystalHarness(ctx, x, y, time, form),
  },
  {
    id: 'CO-IN-echovoid-001',
    name: 'Echoing Void Orb',
    type: 'COMPANION',
    slot: 'companion',
    band: 'INDIGO',
    rarity: 'Rare',
    description: 'Temporal companion listening for time cracks.',
    fullDescription: 'Floats near the wearer, slightly out of sync. Rings expand and echo.',
    renderFn: (ctx, x, y, time, form) => renderEchoOrb(ctx, x, y, time, form),
  },
]

const BANDS = {
  RED: { name: 'Impact', color: '#FF6B35' },
  ORANGE: { name: 'Kinetic', color: '#ff6b35' },
  YELLOW: { name: 'Radiant', color: '#F4B942' },
  GREEN: { name: 'Growth', color: '#4ECDC4' },
  BLUE: { name: 'Flow', color: '#4ECDC4' },
  INDIGO: { name: 'Phase', color: '#A29BFE' },
  PURPLE: { name: 'Transcendent', color: '#a855f7' },
}

const FORMS = {
  radiant: { name: "Radiant Guardian", baseColor: "#2C3E77", primaryGold: "#F4B942", secondaryGold: "#FFD700", tealAccent: "#4ECDC4", eyeColor: "#F4B942" },
  meditation: { name: "Meditation Cocoon", baseColor: "#0d1321", primaryGold: "#2DD4BF", secondaryGold: "#4ECDC4", tealAccent: "#1a4d4d", eyeColor: "#2DD4BF" },
  sage: { name: "Sage Luminary", baseColor: "#1a1f3a", primaryGold: "#FFD700", secondaryGold: "#F4B942", tealAccent: "#4ECDC4", eyeColor: "#FFD700" },
  vigilant: { name: "Vigilant Sentinel", baseColor: "#1a1f3a", primaryGold: "#FF6B35", secondaryGold: "#FF8C42", tealAccent: "#4ECDC4", eyeColor: "#FF6B35" },
}

// ===== ADDON RENDER FUNCTIONS =====
function renderChronoGoggles(ctx, x, y, time, form) {
  const shimmerAlpha = Math.sin(time * 0.004) * 0.3 + 0.5
  const glowColor = `rgba(162, 155, 254, ${shimmerAlpha * 0.6})`
  
  // Left lens
  ctx.save()
  ctx.translate(x - 8, y - 65)
  ctx.strokeStyle = glowColor
  ctx.lineWidth = 2.5
  ctx.beginPath()
  ctx.arc(0, 0, 12, 0, Math.PI * 2)
  ctx.stroke()
  
  ctx.strokeStyle = `rgba(162, 155, 254, ${shimmerAlpha * 0.3})`
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.arc(0, 0, 14, 0, Math.PI * 2)
  ctx.stroke()
  ctx.restore()

  // Right lens
  ctx.save()
  ctx.translate(x + 8, y - 65)
  ctx.strokeStyle = glowColor
  ctx.lineWidth = 2.5
  ctx.beginPath()
  ctx.arc(0, 0, 12, 0, Math.PI * 2)
  ctx.stroke()
  
  ctx.strokeStyle = `rgba(162, 155, 254, ${shimmerAlpha * 0.3})`
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.arc(0, 0, 14, 0, Math.PI * 2)
  ctx.stroke()
  ctx.restore()

  // Bridge
  ctx.strokeStyle = glowColor
  ctx.lineWidth = 1.5
  ctx.beginPath()
  ctx.moveTo(x - 6, y - 65)
  ctx.lineTo(x + 6, y - 65)
  ctx.stroke()
}

function renderAuraSentience(ctx, x, y, time, form) {
  const glowRadius = 85 + Math.sin(time * 0.002) * 10
  const glowAlpha = 0.4 + Math.sin(time * 0.003) * 0.2
  
  // Main aura ring
  ctx.strokeStyle = `rgba(244, 185, 66, ${glowAlpha * 0.6})`
  ctx.lineWidth = 3
  ctx.beginPath()
  ctx.arc(x, y, glowRadius, 0, Math.PI * 2)
  ctx.stroke()

  // Secondary ring
  ctx.strokeStyle = `rgba(255, 215, 0, ${glowAlpha * 0.3})`
  ctx.lineWidth = 1.5
  ctx.beginPath()
  ctx.arc(x, y, glowRadius + 15, 0, Math.PI * 2)
  ctx.stroke()

  // Sparkles
  for (let i = 0; i < 12; i++) {
    const angle = (i / 12) * Math.PI * 2 + time * 0.001
    const r = glowRadius - 5
    const sx = x + Math.cos(angle) * r
    const sy = y + Math.sin(angle) * r
    const sparkleAlpha = Math.sin(time * 0.004 + i * 0.5) * 0.5 + 0.5
    
    ctx.fillStyle = `rgba(244, 185, 66, ${sparkleAlpha})`
    ctx.beginPath()
    ctx.arc(sx, sy, 2.5, 0, Math.PI * 2)
    ctx.fill()
  }
}

function renderMantleStarlight(ctx, x, y, time, form) {
  const mantleTime = time * 0.0015
  const waveAmp = 20 + Math.sin(mantleTime) * 10
  
  // Flowing mantle shape
  ctx.strokeStyle = `rgba(78, 205, 196, 0.5)`
  ctx.lineWidth = 2.5
  ctx.beginPath()
  ctx.moveTo(x - 35, y + 50)
  ctx.quadraticCurveTo(x - 55, y + 90 + Math.sin(mantleTime) * waveAmp, x - 20, y + 150)
  ctx.quadraticCurveTo(x, y + 160 + Math.sin(mantleTime + 0.5) * 10, x + 20, y + 150)
  ctx.quadraticCurveTo(x + 55, y + 90 + Math.sin(mantleTime + 1) * waveAmp, x + 35, y + 50)
  ctx.stroke()

  // Stars scattered in mantle
  for (let i = 0; i < 7; i++) {
    const starX = x - 30 + (i / 7) * 60 + Math.sin(mantleTime + i) * 15
    const starY = y + 70 + (i / 7) * 50 + Math.cos(mantleTime + i * 0.3) * 10
    const starAlpha = 0.6 + Math.sin(mantleTime + i * 0.4) * 0.4
    
    ctx.fillStyle = `rgba(78, 205, 196, ${starAlpha})`
    ctx.beginPath()
    ctx.arc(starX, starY, 2, 0, Math.PI * 2)
    ctx.fill()
  }

  // Trailing mist effect
  ctx.strokeStyle = `rgba(78, 205, 196, 0.2)`
  ctx.lineWidth = 1
  for (let i = 0; i < 3; i++) {
    const offsetX = x + (i - 1) * 20
    ctx.beginPath()
    ctx.moveTo(offsetX, y + 50)
    ctx.quadraticCurveTo(offsetX - 20, y + 100, offsetX + 10, y + 150)
    ctx.stroke()
  }
}

function renderPhoenixWings(ctx, x, y, time, form) {
  const wingTime = time * 0.003
  const wingExpand = Math.sin(wingTime) * 0.15 + 1
  const shockAlpha = Math.sin(wingTime * 2) * 0.4 + 0.5

  // Left wing
  ctx.save()
  ctx.translate(x - 40, y + 10)
  ctx.scale(-1 * wingExpand, wingExpand)
  
  ctx.fillStyle = 'rgba(255, 107, 53, 0.7)'
  ctx.beginPath()
  ctx.moveTo(0, 0)
  ctx.lineTo(-50, -35)
  ctx.quadraticCurveTo(-45, -15, -25, 0)
  ctx.closePath()
  ctx.fill()

  ctx.strokeStyle = '#FFD700'
  ctx.lineWidth = 1.5
  ctx.stroke()
  
  ctx.restore()

  // Right wing
  ctx.save()
  ctx.translate(x + 40, y + 10)
  ctx.scale(wingExpand, wingExpand)
  
  ctx.fillStyle = 'rgba(255, 107, 53, 0.7)'
  ctx.beginPath()
  ctx.moveTo(0, 0)
  ctx.lineTo(50, -35)
  ctx.quadraticCurveTo(45, -15, 25, 0)
  ctx.closePath()
  ctx.fill()

  ctx.strokeStyle = '#FFD700'
  ctx.lineWidth = 1.5
  ctx.stroke()
  
  ctx.restore()

  // Shock rings
  ctx.strokeStyle = `rgba(251, 191, 36, ${shockAlpha * 0.7})`
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.arc(x, y + 10, 50 + Math.sin(wingTime) * 15, 0, Math.PI * 2)
  ctx.stroke()

  ctx.strokeStyle = `rgba(251, 191, 36, ${shockAlpha * 0.3})`
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.arc(x, y + 10, 70 + Math.sin(wingTime + 0.5) * 20, 0, Math.PI * 2)
  ctx.stroke()
}

function renderPrismFamiliar(ctx, x, y, time, form) {
  const familiarTime = time * 0.002
  const fx = x + 65 + Math.sin(familiarTime) * 25
  const fy = y - 25 + Math.cos(familiarTime * 0.7) * 20

  // Prism body
  ctx.fillStyle = '#F4B942'
  ctx.beginPath()
  ctx.moveTo(fx, fy - 14)
  ctx.lineTo(fx + 12, fy + 8)
  ctx.lineTo(fx - 12, fy + 8)
  ctx.closePath()
  ctx.fill()

  ctx.strokeStyle = '#FFD700'
  ctx.lineWidth = 1.5
  ctx.stroke()

  // Halo ring
  ctx.strokeStyle = `rgba(244, 185, 66, 0.7)`
  ctx.lineWidth = 1.5
  ctx.beginPath()
  ctx.arc(fx, fy, 18, 0, Math.PI * 2)
  ctx.stroke()

  // Prism sparkles (orbiting)
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2 + familiarTime * 1.5
    const sx = fx + Math.cos(angle) * 22
    const sy = fy + Math.sin(angle) * 22
    const sparkleAlpha = Math.sin(familiarTime * 0.005 + i * 0.6) * 0.5 + 0.6
    
    ctx.fillStyle = `rgba(244, 185, 66, ${sparkleAlpha})`
    ctx.beginPath()
    ctx.arc(sx, sy, 2, 0, Math.PI * 2)
    ctx.fill()
  }
}

function renderCrystalHarness(ctx, x, y, time, form) {
  const crystalTime = time * 0.002
  const breatheScale = 1 + Math.sin(crystalTime) * 0.1
  const glowAlpha = 0.4 + Math.sin(crystalTime) * 0.2

  ctx.save()
  ctx.translate(x, y + 20)
  ctx.scale(breatheScale, breatheScale)

  // Heart-shaped crystal structure
  ctx.strokeStyle = `rgba(78, 205, 196, ${glowAlpha})`
  ctx.lineWidth = 1.5
  
  // Draw organic crystalline shape
  ctx.beginPath()
  ctx.moveTo(0, -10)
  for (let i = 0; i < 12; i++) {
    const angle = (i / 12) * Math.PI * 2
    const r = 18 + Math.sin(crystalTime + angle * 2) * 4
    const px = Math.cos(angle) * r
    const py = Math.sin(angle) * r
    if (i === 0) ctx.moveTo(px, py)
    else ctx.lineTo(px, py)
  }
  ctx.closePath()
  ctx.stroke()

  // Vein structure with glow
  ctx.strokeStyle = `rgba(78, 205, 196, ${glowAlpha * 0.6})`
  ctx.lineWidth = 0.8
  for (let i = 0; i < 4; i++) {
    const angle = (i / 4) * Math.PI * 2
    const endX = Math.cos(angle) * 28
    const endY = Math.sin(angle) * 28
    ctx.beginPath()
    ctx.moveTo(0, 0)
    ctx.quadraticCurveTo(Math.cos(angle) * 15, Math.sin(angle) * 15, endX, endY)
    ctx.stroke()
  }

  ctx.restore()
}

function renderEchoOrb(ctx, x, y, time, form) {
  const echoTime = time * 0.0025
  const ringAlpha = Math.sin(echoTime) * 0.4 + 0.5

  // Core orb
  ctx.fillStyle = `rgba(162, 155, 254, 0.8)`
  ctx.beginPath()
  ctx.arc(x + 55, y - 30, 10, 0, Math.PI * 2)
  ctx.fill()

  // Concentric echo rings
  for (let i = 0; i < 3; i++) {
    const ringRadius = 20 + i * 12 + Math.sin(echoTime + i * 0.5) * 8
    const alpha = ringAlpha * (0.7 - i * 0.2)
    ctx.strokeStyle = `rgba(162, 155, 254, ${alpha})`
    ctx.lineWidth = 1.2
    ctx.beginPath()
    ctx.arc(x + 55, y - 30, ringRadius, 0, Math.PI * 2)
    ctx.stroke()
  }

  // Temporal echo ghost
  const ghostRadius = 25 + Math.sin(echoTime * 1.5) * 12
  ctx.strokeStyle = `rgba(162, 155, 254, ${ringAlpha * 0.3})`
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.arc(x + 55, y - 30, ghostRadius, 0, Math.PI * 2)
  ctx.stroke()
}

// ===== MAIN SHOWCASE COMPONENT =====
function AuraliaAddonShowcaseSVG({ equippedAddons, form }) {
  const fieldRef = useRef(initField('AURALIA'))
  const animationRef = useRef(0)

  return (
    <svg viewBox="0 0 400 400" className="w-full h-full" style={{ background: 'linear-gradient(135deg, rgba(45, 62, 119, 0.2), rgba(13, 19, 33, 0.2))' }}>
      <defs>
        <filter id="auraliGlow">
          <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
          <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>

      {/* Core breathing aura */}
      <g filter="url(#auraliGlow)">
        <circle cx="200" cy="200" r="140" fill={FORMS[form].primaryGold} opacity="0.08" />
        <circle cx="200" cy="200" r="110" fill={FORMS[form].tealAccent} opacity="0.05" />
      </g>

      {/* Orbital rings */}
      <g opacity="0.2">
        <circle cx="200" cy="200" r="150" fill="none" stroke={FORMS[form].primaryGold} strokeWidth="0.8" />
        <circle cx="200" cy="200" r="125" fill="none" stroke={FORMS[form].tealAccent} strokeWidth="0.6" />
        <circle cx="200" cy="200" r="100" fill="none" stroke={FORMS[form].primaryGold} strokeWidth="0.5" />
      </g>

      {/* Main body (simplified SVG) */}
      <g>
        {/* Head */}
        <circle cx="200" cy="145" r="35" fill={FORMS[form].baseColor} stroke={FORMS[form].primaryGold} strokeWidth="2" />
        
        {/* Eyes */}
        <circle cx="190" cy="140" r="4" fill={FORMS[form].eyeColor} />
        <circle cx="210" cy="140" r="4" fill={FORMS[form].eyeColor} />

        {/* Body */}
        <ellipse cx="200" cy="210" rx="32" ry="50" fill={FORMS[form].baseColor} stroke={FORMS[form].primaryGold} strokeWidth="2" />
      </g>
    </svg>
  )
}

function AuraliaCanvasShowcase({ equippedAddons, form }) {
  const canvasRef = useRef(null)
  const animationRef = useRef(null)
  const fieldRef = useRef(initField('AURALIA'))

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resize = () => {
      const rect = canvas.parentElement?.getBoundingClientRect()
      if (!rect) return
      const dpr = window.devicePixelRatio || 1
      canvas.width = rect.width * dpr
      canvas.height = rect.height * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    window.addEventListener('resize', resize)

    const animate = (time) => {
      const w = canvas.width / (window.devicePixelRatio || 1)
      const h = canvas.height / (window.devicePixelRatio || 1)

      // Clear
      ctx.fillStyle = 'rgba(2, 6, 23, 0.08)'
      ctx.fillRect(0, 0, w, h)

      const centerX = w / 2
      const centerY = h / 2.2

      // Breathing background glow
      const glowAlpha = Math.sin(time * 0.001) * 0.15 + 0.15
      ctx.fillStyle = `rgba(244, 185, 66, ${glowAlpha * 0.2})`
      ctx.beginPath()
      ctx.arc(centerX, centerY, 120, 0, Math.PI * 2)
      ctx.fill()

      // Rings
      ctx.strokeStyle = `rgba(244, 185, 66, 0.15)`
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.arc(centerX, centerY, 100, 0, Math.PI * 2)
      ctx.stroke()
      ctx.beginPath()
      ctx.arc(centerX, centerY, 130, 0, Math.PI * 2)
      ctx.stroke()

      // Auralia body geometry
      ctx.fillStyle = FORMS[form].baseColor
      ctx.strokeStyle = FORMS[form].primaryGold
      ctx.lineWidth = 2

      // Head
      ctx.beginPath()
      ctx.arc(centerX, centerY - 50, 32, 0, Math.PI * 2)
      ctx.fill()
      ctx.stroke()

      // Eyes
      ctx.fillStyle = FORMS[form].eyeColor
      ctx.beginPath()
      ctx.arc(centerX - 10, centerY - 55, 4, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.arc(centerX + 10, centerY - 55, 4, 0, Math.PI * 2)
      ctx.fill()

      // Body
      ctx.fillStyle = FORMS[form].baseColor
      ctx.strokeStyle = FORMS[form].primaryGold
      ctx.beginPath()
      ctx.ellipse(centerX, centerY + 15, 28, 45, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.stroke()

      // Render equipped addons
      equippedAddons.forEach(addonId => {
        const addon = ADDON_ITEMS.find(a => a.id === addonId)
        if (addon && addon.renderFn) {
          addon.renderFn(ctx, centerX, centerY, time, FORMS[form])
        }
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    animationRef.current = requestAnimationFrame(animate)

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      window.removeEventListener('resize', resize)
    }
  }, [equippedAddons, form])

  return <canvas ref={canvasRef} className="w-full h-96 rounded-lg border border-slate-700/50 bg-gradient-to-br from-slate-950 to-black" />
}

export default function AuraliaAddonShowcaseProduction() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [equippedAddons, setEquippedAddons] = useState(['BK-RD-phoenix-001'])
  const [form, setForm] = useState('radiant')
  const [isAutoPlay, setIsAutoPlay] = useState(true)
  const autoplayRef = useRef(null)

  useEffect(() => {
    if (!isAutoPlay) {
      if (autoplayRef.current) clearInterval(autoplayRef.current)
      return
    }

    autoplayRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % ADDON_ITEMS.length)
    }, 5000)

    return () => {
      if (autoplayRef.current) clearInterval(autoplayRef.current)
    }
  }, [isAutoPlay])

  const current = ADDON_ITEMS[currentIndex]
  const band = BANDS[current.band]
  const isEquipped = equippedAddons.includes(current.id)

  const toggleEquip = () => {
    setEquippedAddons((prev) => {
      if (prev.includes(current.id)) {
        return prev.filter((id) => id !== current.id)
      } else {
        return [...prev, current.id]
      }
    })
  }

  const goNext = () => {
    setCurrentIndex((prev) => (prev + 1) % ADDON_ITEMS.length)
    setIsAutoPlay(false)
  }

  const goPrev = () => {
    setCurrentIndex((prev) => (prev - 1 + ADDON_ITEMS.length) % ADDON_ITEMS.length)
    setIsAutoPlay(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-black text-slate-100">
      <div className="border-b border-slate-800/50 bg-gradient-to-b from-slate-900/50 to-transparent px-6 py-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="h-8 w-8 text-amber-400" />
            <h1 className="text-4xl font-light tracking-wider">AURALIA ADDON SHOWCASE</h1>
          </div>
          <p className="text-sm text-slate-400">
            High-fidelity Moss60 rendering with live addon equipping. Watch Auralia transform in real-time.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-12 space-y-12">
        {/* Main Showcase */}
        <div className="rounded-lg border border-slate-700/50 bg-slate-900/40 p-6">
          {/* Canvas Rendering */}
          <div className="mb-6">
            <h2 className="mb-4 text-sm font-bold uppercase tracking-wider text-slate-300">Live Rendering</h2>
            <AuraliaCanvasShowcase equippedAddons={equippedAddons} form={form} />
          </div>

          {/* Form Selector */}
          <div className="mb-6 p-4 rounded border border-slate-700/50 bg-slate-800/30">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Guardian Form</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {Object.entries(FORMS).map(([key, value]) => (
                <button
                  key={key}
                  onClick={() => setForm(key)}
                  className={`rounded px-3 py-2 text-xs font-bold transition ${
                    form === key
                      ? 'bg-amber-500 text-black'
                      : 'bg-slate-800/50 text-slate-300 hover:bg-slate-700/50'
                  }`}
                >
                  {value.name}
                </button>
              ))}
            </div>
          </div>

          {/* Addon Info & Controls */}
          <div className="space-y-4 border-t border-slate-700/50 pt-6">
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              <div>
                <p className="text-xs text-slate-400 uppercase">Current</p>
                <p className="font-light text-lg text-slate-100">{current.name}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase">Type</p>
                <p className="font-mono text-sm text-slate-300">{current.type}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase">Band</p>
                <p style={{ color: band.color }} className="font-bold">
                  {band.name}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase">Rarity</p>
                <p className="font-mono text-sm text-amber-300">{current.rarity}</p>
              </div>
            </div>

            <p className="text-sm leading-relaxed text-slate-300">{current.fullDescription}</p>

            {/* Controls */}
            <div className="flex gap-3">
              <button
                onClick={goPrev}
                className="flex items-center gap-2 rounded border border-slate-600/50 bg-slate-800/50 px-4 py-2 text-sm transition hover:bg-slate-700/50"
              >
                <ChevronLeft className="h-4 w-4" />
                Prev
              </button>
              <button
                onClick={toggleEquip}
                className={`flex-1 rounded py-2 text-sm font-bold transition ${
                  isEquipped ? 'bg-emerald-600 text-white hover:bg-emerald-500' : 'bg-amber-500 text-black hover:bg-amber-400'
                }`}
              >
                {isEquipped ? '✓ Equipped' : 'Equip Addon'}
              </button>
              <button
                onClick={goNext}
                className="flex items-center gap-2 rounded border border-slate-600/50 bg-slate-800/50 px-4 py-2 text-sm transition hover:bg-slate-700/50"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

            {/* Indicator Dots */}
            <div className="flex justify-center gap-2">
              {ADDON_ITEMS.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setCurrentIndex(idx)
                    setIsAutoPlay(false)
                  }}
                  className={`h-2 rounded-full transition ${idx === currentIndex ? 'w-8 bg-amber-500' : 'w-2 bg-slate-600'}`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Equipped Addons */}
        {equippedAddons.length > 0 && (
          <div className="rounded-lg border border-slate-700/50 bg-slate-900/40 p-6">
            <h3 className="mb-4 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-300">
              <Zap className="h-4 w-4 text-amber-400" />
              Currently Equipped ({equippedAddons.length})
            </h3>
            <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
              {equippedAddons.map((id) => {
                const addon = ADDON_ITEMS.find((a) => a.id === id)
                if (!addon) return null
                const aBand = BANDS[addon.band]
                return (
                  <div key={id} className="rounded border border-slate-700/30 bg-slate-800/50 p-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-sm font-light text-slate-100">{addon.name}</p>
                        <p className="mt-1 text-xs text-slate-400">{addon.type}</p>
                      </div>
                      <button
                        onClick={() => setEquippedAddons((prev) => prev.filter((aid) => aid !== id))}
                        className="text-xs text-slate-400 transition hover:text-slate-100"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="mt-2 pt-2 border-t border-slate-700/30 flex justify-between items-center">
                      <span
                        className="inline-block text-xs font-bold text-black px-2 py-1 rounded"
                        style={{ backgroundColor: aBand.color }}
                      >
                        {aBand.name}
                      </span>
                      <span className="text-xs text-amber-300 font-mono">{addon.rarity}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Full Index */}
        <div className="rounded-lg border border-slate-700/50 bg-slate-900/40 p-6">
          <h3 className="mb-4 text-lg font-light tracking-wider text-slate-100">Addon Index</h3>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {ADDON_ITEMS.map((addon) => {
              const aBand = BANDS[addon.band]
              const equipped = equippedAddons.includes(addon.id)
              return (
                <button
                  key={addon.id}
                  onClick={() => {
                    setCurrentIndex(ADDON_ITEMS.indexOf(addon))
                    setIsAutoPlay(false)
                  }}
                  className={`rounded-lg border p-3 transition text-left ${
                    equipped
                      ? 'border-emerald-500 bg-emerald-950/40'
                      : 'border-slate-700/50 bg-slate-800/30 hover:bg-slate-800/50'
                  }`}
                >
                  <p className="text-sm font-light text-slate-100">{addon.name}</p>
                  <p className="mt-1 text-xs text-slate-400">{addon.type}</p>
                  <div className="mt-2 pt-2 border-t border-slate-700/30 flex justify-between items-center">
                    <span
                      className="text-xs font-bold text-black px-1.5 py-0.5 rounded"
                      style={{ backgroundColor: aBand.color }}
                    >
                      {aBand.name}
                    </span>
                    <span className="text-xs text-slate-400">{addon.rarity}</span>
                  </div>
                </button>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
