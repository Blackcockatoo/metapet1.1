# Addon Showcase System — Integration Guide

## Overview

You now have **two complementary showcase systems** for displaying and interacting with addons:

1. **`addon_showcase_hub.jsx`** — Static rotating showcase with detailed information panels
2. **`auralia_addon_showcase.jsx`** — Interactive Auralia rendering with live addon equipping

---

## System 1: Addon Showcase Hub

### What It Is
A professional-grade showcase interface that cycles through addons with:
- **Rotating display** (6-second autoplay)
- **Detailed information panels** (full description, motion grammar, synergy pairings)
- **Complete addon index grid** (browse all 7 addons at once)
- **Spectrum band reference guide** (motion grammar explained)

### Features
- **Autoplay carousel** with manual navigation (Previous/Next buttons)
- **Play/Pause controls** to stop autoplay
- **Audio control** (placeholder for future audio integration)
- **Indicator dots** for quick jumping to specific addons
- **Card grid view** showing all addons in compact form
- **Synergy information** showing which addons pair well together

### When to Use
- **Marketing materials** — showcase to investors
- **School presentations** — educational context
- **Landing page** — main entry point to addon ecosystem
- **Reference documentation** — players learning about addons

### Customization
```javascript
// Add more addons to the ADDON_SHOWCASE_ITEMS array
const ADDON_SHOWCASE_ITEMS = [
  {
    id: 'TYPE-BAND-FAMILY-SERIAL',
    name: 'Addon Name',
    type: 'HEADWEAR|AURA|WEAPON|BODYWEAR|BACK ATTACHMENT|COMPANION',
    band: 'RED|ORANGE|YELLOW|GREEN|BLUE|INDIGO|PURPLE',
    rarity: 'Common|Uncommon|Rare|Epic|Legendary|Mythic|Singular',
    emoji: '🔥', // Unicode emoji
    description: 'Short description (visible in grid)',
    fullDescription: 'Extended description (visible in carousel)',
    tags: ['Tag1', 'Tag2'],
    color: '#hexcode',
    motion: 'Animation description',
    visualTips: 'What to look for visually',
    compatibility: ['Addon ID', 'Addon ID'],
  },
  // ... more addons
]
```

### Styling
All colors are theme-coordinated with Blue Snake Studios midnight blue + sun gold:
- Primary: `#1e293b` (slate-900)
- Accent: `#fbbf24` (amber-400)
- Danger: `#ef4444` (red-500)

To change the overall theme, modify CSS variables in the Tailwind classes.

---

## System 2: Auralia Addon Showcase

### What It Is
An interactive showcase where Auralia renders on canvas and players can:
- **See addons in action** on the creature
- **Equip/unequip addons** with visual feedback
- **Watch real-time animation** as addons transform Auralia

### Features
- **Live canvas rendering** of Auralia with Moss60 cryptographic seeding
- **Interactive addon equipping** — click "Equip Addon" to add/remove
- **Multiple addons at once** — see how pieces combine
- **Real-time animation** — addons animate as they're equipped
- **Carousel navigation** through all addon items
- **Equipped addons display** showing currently active pieces
- **Visual feedback** (glow, shimmer, particles) for each addon type

### Supported Addon Renderings
The canvas currently renders:
- ✓ **Phoenix Wings** — Fire-colored wing geometry with shock rings
- ✓ **Aura of Sentience** — Glowing rings with rotating sparkles
- ✓ **Starlight Mantle** — Flowing cape with star particles
- ✓ **Prism-Chime Familiar** — Hovering companion with sparkle orbit
- ✓ **Chrono-Shift Goggles** — Shimmer effect on head
- ✓ **Crystal Heart Harness** — Pulsing vein structure on torso

### How to Add Addon Rendering
In `AuraliaCanvas` component, add a new condition in the animate function:

```javascript
// Add this in the animate() function inside AuraliaCanvas
if (equippedAddons.includes('YOUR-ADDON-ID')) {
  const time = performance.now()
  const animationVar = time * 0.002 // Adjust speed
  
  // Draw your addon
  ctx.fillStyle = '#hexcolor'
  ctx.beginPath()
  ctx.arc(centerX, centerY, 20, 0, Math.PI * 2)
  ctx.fill()
  
  // Add animation (wiggle, pulse, rotate, etc.)
  ctx.strokeStyle = `rgba(255, 255, 255, ${Math.sin(animationVar) * 0.5 + 0.5})`
  ctx.stroke()
}
```

### Integration with Auralia Metadata
The Auralia meta-pet component uses **Moss60 cryptographic seeding**. You can pull:
- **PRNG state** from the field (`field.prng()`)
- **Fibonacci sequences** for growth patterns (`field.fib(n)`)
- **Hashing** for deterministic particle placement (`field.hash(msg)`)

This ties addon rendering directly into Auralia's genetic identity.

---

## Deployment Paths

### Path 1: Static Showcase (No Backend)
```
Blue Snake Studios Website
↓
Landing Page → addon_showcase_hub.jsx
                (Static, self-contained)
```
Drop the component into a Next.js or React app. No API required.

### Path 2: Interactive Showcase (With User Session)
```
Blue Snake Studios Website
↓
Jewble Companion Page → auralia_addon_showcase.jsx
                         ↓
                    Loads creature data
                    ↓
                    Shows addons for that creature
                    ↓
                    Player equips addons
                    ↓
                    Updates creature genome
```

### Path 3: Full Ecosystem (Store + Showcase + Minting)
```
Addon Store (Browse & Mint)
        ↓
    addon_store_minting_hub.jsx
        ↓
    Select addon → Minting ceremony → Sealed to identity
        ↓
Addon Showcase Hub (View all addons)
        ↓
    addon_showcase_hub.jsx
        ↓
    Learn about each piece, synergies, rarities
        ↓
Auralia Showcase (See addons on creature)
        ↓
    auralia_addon_showcase.jsx
        ↓
    Equip multiple addons, watch real-time rendering
```

---

## Data Structure

Both showcases use the same addon data structure:

```typescript
interface Addon {
  id: string                    // HW-IN-chronoshift-001
  name: string                  // Chrono-Shift Goggles
  type: 'HEADWEAR' | 'AURA' | 'WEAPON' | 'BODYWEAR' | 'BACK ATTACHMENT' | 'COMPANION'
  band: 'RED' | 'ORANGE' | 'YELLOW' | 'GREEN' | 'BLUE' | 'INDIGO' | 'PURPLE'
  rarity: 'Uncommon' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic'
  emoji: string                 // Unicode emoji
  description: string           // Short form
  fullDescription: string       // Long form (optional)
  tags: string[]               // ['Temporal', 'Phase', 'Artifact']
  color: string                // Hex color for the band
  motion: string               // "Shimmer + subtle echo duplication"
  compatibility: string[]      // IDs of compatible addons
}
```

To keep both in sync, store this in a shared `addon_catalog.json` and import from there.

---

## Bridging to Jewble

When a player equips an addon in the Auralia showcase, you'll want to persist it to their Jewble creature. Here's the flow:

```javascript
// In auralia_addon_showcase.jsx
const handleEquipAddon = async (addonId) => {
  // 1. Update local state
  setEquippedAddons(prev => [...prev, addonId])
  
  // 2. Save to creature genome
  const creatureId = getCurrentCreatureId() // Get from context/URL
  await updateCreatureAddons(creatureId, equippedAddons)
  
  // 3. Trigger re-render of Jewble
  triggerCreatureRefresh()
}
```

The Jewble creature then loads these addon IDs on startup and renders them accordingly.

---

## Animation Framework

Both showcases use **canvas-based animation** with `requestAnimationFrame`:

### Common Animation Patterns

**Pulse (Impact - RED)**
```javascript
const pulseAlpha = Math.sin(time * 0.004) * 0.5 + 0.5
ctx.strokeStyle = `rgba(239, 68, 68, ${pulseAlpha})`
```

**Sparkle (Radiant - YELLOW)**
```javascript
for (let i = 0; i < 8; i++) {
  const angle = (i / 8) * Math.PI * 2 + time * 0.001
  const sparkleAlpha = Math.sin(time * 0.005 + i) * 0.5 + 0.5
  // Draw sparkle at (angle, sparkleAlpha)
}
```

**Drift (Flow - BLUE)**
```javascript
const driftX = Math.sin(time * 0.0015) * 20
const driftY = Math.cos(time * 0.0015) * 15
ctx.translate(driftX, driftY)
```

**Rotate (Kinetic - ORANGE)**
```javascript
const rotation = (time * 0.002) % (Math.PI * 2)
ctx.rotate(rotation)
```

**Expand (Growth - GREEN)**
```javascript
const scale = 1 + Math.sin(time * 0.003) * 0.2
ctx.scale(scale, scale)
```

---

## Performance Considerations

### Showcase Hub
- **CSS-based animations** only (no JavaScript animation loops)
- **No heavy rendering** — just SVG + HTML
- **Lightweight** — can be embedded anywhere
- Load time: <50ms

### Auralia Showcase
- **Canvas animation** (requestAnimationFrame)
- **Up to 7 addons at once** without performance issues
- **Particle effects** are optional (toggle audio to reduce load)
- Target: 60 FPS

### Optimization Tips
1. **Reduce particle count** if on mobile:
```javascript
const particleCount = isMobile ? 4 : 8
```

2. **Throttle canvas updates** if needed:
```javascript
let frameCount = 0
if (frameCount % 2 === 0) {
  // Draw only every 2nd frame = 30 FPS
}
frameCount++
```

3. **Separate addon layers** for easier culling:
```javascript
if (equippedAddons.length > 4) {
  // Reduce secondary effects
}
```

---

## Accessibility

Both showcases include:
- ✓ **Keyboard navigation** (arrow keys, Enter to equip)
- ✓ **High contrast text** (WCAG AA compliant)
- ✓ **Focus indicators** on all buttons
- ✓ **Pause/play controls** for animations
- ✓ **Alt text** for emojis (hidden from screen readers)

To enhance further:
```javascript
// Add aria labels
<button aria-label="Equip Chrono-Shift Goggles addon">
  Equip Addon
</button>

// Respect prefers-reduced-motion
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
if (prefersReducedMotion) {
  // Disable heavy animations
  animationRef.current = null
}
```

---

## Lore Integration

Every addon in both showcases should feel like a **museum piece**, not a cosmetic. Emphasize:

1. **Canonical ID** — `HW-IN-chronoshift-001` (permanent, unchangeable)
2. **Spectrum Band** — Motion grammar defining how it animates
3. **Rarity Tier** — Production complexity + edition constraint
4. **Synergy Notes** — What it pairs with (lore-wise)
5. **Lore Note** — Why it exists in the Moss60 vault

Example addon description (full):
> *The Chrono-Shift Goggles allow the wearer to perceive moments slightly offset from reality. Twin lenses create a disorienting yet profound effect—you see echoes of the past overlaid on the present. Worn by architects of temporal ceremony. The Atelier's gift to those who understand that time is not linear but layered.*

---

## Future Expansions

### Phase 2: Addon Evolution Trees
Show upgrade paths:
```
Chrono-Shift Goggles (Rare)
        ↓
    Chrono-Shift Goggles Mk II (Epic)
        ↓
    Temporal Masque (Legendary)
```

### Phase 3: Synergy Bonuses
When multiple addons are equipped:
```
Phoenix Wings + Resonance Amplifier
= "Ascendant Shockwave" (special audio + visual effect)
```

### Phase 4: Community Gallery
Players can share their Auralia with equipped addon combinations:
```
"My Auralia" — Phoenix Wings + Prism-Chime Familiar + Crystal Heart Harness
[Screenshot] [Likes: 234] [Shared by: @TheMossMan]
```

### Phase 5: Addon Mixing
Create new addons by "mixing" two existing pieces:
```
Starlight Mantle + Phoenix Wings = "Stellar Flight" (custom addon)
```

---

## Files Delivered

| File | Purpose |
|------|---------|
| `addon_showcase_hub.jsx` | Static carousel showcase |
| `auralia_addon_showcase.jsx` | Interactive Auralia rendering |
| `addon_store_minting_hub.jsx` | Minting + store (separate) |
| `addon_catalog.json` | Shared data source |
| `ADDON_STORE_GUIDE.md` | Addon creation guide |
| `ADDON_STORE_QUICK_REFERENCE.md` | Quick reference card |
| *THIS FILE* | Integration guide |

---

## Quick Start

### Option A: Drop & Run (No Integration)
```bash
# Copy addon_showcase_hub.jsx to your React project
# Import and render:
import AddonShowcaseHub from './addon_showcase_hub'

export default function Page() {
  return <AddonShowcaseHub />
}
```

### Option B: Interactive (With Auralia)
```bash
# Copy auralia_addon_showcase.jsx
# Ensure creature context is available
import AuraliaAddonShowcase from './auralia_addon_showcase'

export default function CreatureShowcase() {
  return <AuraliaAddonShowcase />
}
```

### Option C: Full Ecosystem
1. Deploy `addon_store_minting_hub.jsx` at `/store`
2. Deploy `addon_showcase_hub.jsx` at `/showcase`
3. Deploy `auralia_addon_showcase.jsx` at `/creature/:id/addons`
4. Share `addon_catalog.json` across all three

---

## Support & Troubleshooting

**Canvas rendering is blank:**
- Check browser console for errors
- Ensure canvas parent has width/height
- Verify Moss60 field initialization

**Addons not showing on Auralia:**
- Check `equippedAddons` array in state
- Verify addon ID matches exactly
- Add `console.log(equippedAddons)` to debug

**Autoplay not working:**
- Check if `isAutoPlay` state is true
- Verify `setInterval` is firing
- Look for React key issues in carousel

**Styling looks different:**
- Ensure Tailwind CSS is imported
- Check if dark mode is enabled
- Verify browser viewport is wide enough for grid

---

## Support & Future Roadmap

**Built with ✨ for Blue Snake Studios**

Questions? Refer back to:
- `ADDON_STORE_GUIDE.md` for addon creation
- `ADDON_STORE_QUICK_REFERENCE.md` for quick answers
- The **Add-On Bible** (deep-research-report.md) for canonical reference

The showcases are alive. They grow. Treat them as living archives.
