'use client'

import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react'
import { ChevronLeft, ChevronRight, Sparkles, Zap } from 'lucide-react'

// ===== ADDON CATALOG =====
const ADDON_ITEMS = [
  {
    id: 'HW-IN-chronoshift-001',
    name: 'Chrono-Shift Goggles',
    type: 'HEADWEAR',
    band: 'INDIGO',
    rarity: 'Legendary',
    emoji: '⏱️',
    fullName: 'Chrono-Shift Goggles',
  },
  {
    id: 'AU-YL-sentience-001',
    name: 'Aura of Sentience',
    type: 'AURA',
    band: 'YELLOW',
    rarity: 'Epic',
    emoji: '✨',
    fullName: 'Aura of Sentience',
  },
  {
    id: 'BK-BL-starlight-001',
    name: 'Starlight Mantle',
    type: 'BACK ATTACHMENT',
    band: 'BLUE',
    rarity: 'Epic',
    emoji: '🌙',
    fullName: 'Starlight Mantle',
  },
  {
    id: 'BK-RD-phoenix-001',
    name: 'Phoenix Wings',
    type: 'BACK ATTACHMENT',
    band: 'RED',
    rarity: 'Legendary',
    emoji: '🔥',
    fullName: 'Phoenix Wings',
  },
  {
    id: 'CO-YL-familiar-001',
    name: 'Prism-Chime Familiar',
    type: 'COMPANION',
    band: 'YELLOW',
    rarity: 'Legendary',
    emoji: '🔮',
    fullName: 'Prism-Chime Familiar',
  },
  {
    id: 'BW-GN-crystalheart-001',
    name: 'Crystal Heart Harness',
    type: 'BODYWEAR',
    band: 'GREEN',
    rarity: 'Rare',
    emoji: '💎',
    fullName: 'Crystal Heart Harness',
  },
  {
    id: 'CO-IN-echovoid-001',
    name: 'Echoing Void Orb',
    type: 'COMPANION',
    band: 'INDIGO',
    rarity: 'Rare',
    emoji: '◯',
    fullName: 'Echoing Void Orb',
  },
]

const BANDS = {
  RED: { name: 'Impact', color: '#ef4444' },
  ORANGE: { name: 'Kinetic', color: '#ff6b35' },
  YELLOW: { name: 'Radiant', color: '#f59e0b' },
  GREEN: { name: 'Growth', color: '#10b981' },
  BLUE: { name: 'Flow', color: '#3b82f6' },
  INDIGO: { name: 'Phase', color: '#6b46c1' },
  PURPLE: { name: 'Transcendent', color: '#a855f7' },
}

// ===== MOSS60 CORE (Simplified) =====
const initField = (seedName = 'AURALIA') => {
  const seed = BigInt(Math.random() * Number.MAX_SAFE_INTEGER)
  const prng = (() => {
    let x = seed
    return () => {
      x ^= x << 13n
      x ^= x >> 7n
      x ^= x << 17n
      return Number((x & ((1n << 32n) - 1n)) >> 0) / 0x100000000
    }
  })()

  return { seed: seedName, prng }
}

// ===== AURALIA MINIMAL RENDERER =====
function AuraliaCanvas({ equippedAddons, formKey = 'radiant' }) {
  const canvasRef = useRef(null)
  const animationRef = useRef(null)
  const fieldRef = useRef(initField('AURALIA'))

  const forms = {
    radiant: {
      baseColor: '#dba876',
      primaryGold: '#f4d9a6',
      secondaryGold: '#e8c995',
      tealAccent: '#2dd4bf',
      eyeColor: '#1f7a72',
      glowColor: '#f4d9a6',
    },
    meditation: {
      baseColor: '#b8956a',
      primaryGold: '#d4a574',
      secondaryGold: '#c29668',
      tealAccent: '#14b8a6',
      eyeColor: '#0d9488',
      glowColor: '#e8c995',
    },
    sage: {
      baseColor: '#9d8b7e',
      primaryGold: '#bfa89d',
      secondaryGold: '#b39a8f',
      tealAccent: '#06b6d4',
      eyeColor: '#0891b2',
      glowColor: '#bfa89d',
    },
    vigilant: {
      baseColor: '#8b7d6b',
      primaryGold: '#a89969',
      secondaryGold: '#9d8e5f',
      tealAccent: '#06d6ff',
      eyeColor: '#0284c7',
      glowColor: '#a89969',
    },
  }

  const form = forms[formKey]

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resize = () => {
      const rect = canvas.parentElement.getBoundingClientRect()
      canvas.width = rect.width
      canvas.height = rect.height
    }
    resize()
    window.addEventListener('resize', resize)

    const animate = (time) => {
      const w = canvas.width
      const h = canvas.height

      // Clear with fade
      ctx.fillStyle = 'rgba(2, 6, 23, 0.1)'
      ctx.fillRect(0, 0, w, h)

      const centerX = w / 2
      const centerY = h / 2.5

      // ===== Draw Auralia Body =====
      // Head
      ctx.beginPath()
      ctx.arc(centerX, centerY - 60, 35, 0, Math.PI * 2)
      ctx.fillStyle = form.baseColor
      ctx.fill()
      ctx.strokeStyle = form.primaryGold
      ctx.lineWidth = 2
      ctx.stroke()

      // Eyes
      ctx.fillStyle = form.eyeColor
      ctx.beginPath()
      ctx.arc(centerX - 12, centerY - 65, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.arc(centerX + 12, centerY - 65, 5, 0, Math.PI * 2)
      ctx.fill()

      // Eye glow
      ctx.strokeStyle = form.glowColor
      ctx.lineWidth = 1.5
      ctx.beginPath()
      ctx.arc(centerX - 12, centerY - 65, 7, 0, Math.PI * 2)
      ctx.stroke()
      ctx.beginPath()
      ctx.arc(centerX + 12, centerY - 65, 7, 0, Math.PI * 2)
      ctx.stroke()

      // Body
      ctx.beginPath()
      ctx.ellipse(centerX, centerY + 20, 30, 50, 0, 0, Math.PI * 2)
      ctx.fillStyle = form.baseColor
      ctx.fill()
      ctx.strokeStyle = form.primaryGold
      ctx.lineWidth = 2
      ctx.stroke()

      // Aura glow (if aura addon equipped)
      if (equippedAddons.includes('AU-YL-sentience-001')) {
        const glowTime = time * 0.002
        const glowRadius = 80 + Math.sin(glowTime) * 10
        ctx.strokeStyle = `rgba(244, 217, 154, ${0.3 + Math.sin(glowTime) * 0.2})`
        ctx.lineWidth = 3
        ctx.beginPath()
        ctx.arc(centerX, centerY, glowRadius, 0, Math.PI * 2)
        ctx.stroke()

        // Sparkles
        for (let i = 0; i < 8; i++) {
          const angle = (i / 8) * Math.PI * 2 + time * 0.001
          const r = glowRadius - 10
          const sx = centerX + Math.cos(angle) * r
          const sy = centerY + Math.sin(angle) * r
          const sparkleSize = 2 + Math.sin(glowTime + i) * 1
          ctx.fillStyle = `rgba(244, 217, 154, ${0.6 + Math.sin(glowTime + i) * 0.4})`
          ctx.beginPath()
          ctx.arc(sx, sy, sparkleSize, 0, Math.PI * 2)
          ctx.fill()
        }
      }

      // ===== Draw Equipped Addons =====

      // Phoenix Wings (if equipped)
      if (equippedAddons.includes('BK-RD-phoenix-001')) {
        const wingTime = time * 0.003
        const wingScale = 1 + Math.sin(wingTime) * 0.1
        // Left wing
        ctx.save()
        ctx.translate(centerX - 35, centerY + 10)
        ctx.scale(-1 * wingScale, wingScale)
        ctx.fillStyle = 'rgba(239, 68, 68, 0.7)'
        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.lineTo(-40, -30)
        ctx.lineTo(-20, 0)
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = '#fbbf24'
        ctx.lineWidth = 1.5
        ctx.stroke()
        ctx.restore()

        // Right wing
        ctx.save()
        ctx.translate(centerX + 35, centerY + 10)
        ctx.scale(wingScale, wingScale)
        ctx.fillStyle = 'rgba(239, 68, 68, 0.7)'
        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.lineTo(40, -30)
        ctx.lineTo(20, 0)
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = '#fbbf24'
        ctx.lineWidth = 1.5
        ctx.stroke()
        ctx.restore()

        // Shock rings
        const shockAlpha = Math.sin(wingTime * 2) * 0.5 + 0.5
        ctx.strokeStyle = `rgba(251, 191, 36, ${shockAlpha * 0.6})`
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.arc(centerX, centerY + 10, 45 + Math.sin(wingTime) * 10, 0, Math.PI * 2)
        ctx.stroke()
      }

      // Starlight Mantle (if equipped)
      if (equippedAddons.includes('BK-BL-starlight-001')) {
        const mantleTime = time * 0.0015
        ctx.strokeStyle = `rgba(59, 130, 246, 0.5)`
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(centerX - 30, centerY + 50)
        ctx.quadraticCurveTo(centerX - 50, centerY + 80 + Math.sin(mantleTime) * 20, centerX, centerY + 120)
        ctx.quadraticCurveTo(centerX + 50, centerY + 80 + Math.sin(mantleTime + 1) * 20, centerX + 30, centerY + 50)
        ctx.stroke()

        // Stars in mantle
        for (let i = 0; i < 5; i++) {
          const starX = centerX - 30 + (i / 5) * 60 + Math.sin(mantleTime + i) * 20
          const starY = centerY + 70 + (i / 5) * 40
          const starAlpha = 0.5 + Math.sin(mantleTime + i * 0.5) * 0.5
          ctx.fillStyle = `rgba(59, 130, 246, ${starAlpha})`
          ctx.beginPath()
          ctx.arc(starX, starY, 2, 0, Math.PI * 2)
          ctx.fill()
        }
      }

      // Familiar (if equipped)
      if (equippedAddons.includes('CO-YL-familiar-001')) {
        const familiarTime = time * 0.002
        const fx = centerX + 60 + Math.sin(familiarTime) * 20
        const fy = centerY - 30 + Math.cos(familiarTime * 0.7) * 15
        ctx.fillStyle = '#fbbf24'
        ctx.beginPath()
        ctx.arc(fx, fy, 12, 0, Math.PI * 2)
        ctx.fill()
        ctx.strokeStyle = '#f4d9a6'
        ctx.lineWidth = 2
        ctx.stroke()
        // Prism sparkle
        for (let i = 0; i < 4; i++) {
          const angle = (i / 4) * Math.PI * 2 + familiarTime
          const sx = fx + Math.cos(angle) * 18
          const sy = fy + Math.sin(angle) * 18
          const sparkleAlpha = Math.sin(familiarTime + i) * 0.5 + 0.5
          ctx.fillStyle = `rgba(244, 217, 154, ${sparkleAlpha})`
          ctx.beginPath()
          ctx.arc(sx, sy, 2, 0, Math.PI * 2)
          ctx.fill()
        }
      }

      // Chrono-Shift Goggles (if equipped)
      if (equippedAddons.includes('HW-IN-chronoshift-001')) {
        const goggleTime = time * 0.003
        ctx.fillStyle = `rgba(107, 70, 193, ${0.4 + Math.sin(goggleTime) * 0.2})`
        ctx.beginPath()
        ctx.arc(centerX - 10, centerY - 65, 12, 0, Math.PI * 2)
        ctx.fill()
        ctx.beginPath()
        ctx.arc(centerX + 10, centerY - 65, 12, 0, Math.PI * 2)
        ctx.fill()
        // Shimmer
        ctx.strokeStyle = `rgba(196, 181, 253, ${Math.sin(goggleTime) * 0.5 + 0.5})`
        ctx.lineWidth = 1.5
        ctx.beginPath()
        ctx.arc(centerX - 10, centerY - 65, 13, 0, Math.PI * 2)
        ctx.stroke()
        ctx.beginPath()
        ctx.arc(centerX + 10, centerY - 65, 13, 0, Math.PI * 2)
        ctx.stroke()
      }

      // Crystal Heart Harness (if equipped)
      if (equippedAddons.includes('BW-GN-crystalheart-001')) {
        const crystalTime = time * 0.002
        const crystalAlpha = 0.3 + Math.sin(crystalTime) * 0.2
        ctx.strokeStyle = `rgba(16, 185, 129, ${crystalAlpha})`
        ctx.lineWidth = 1.5
        // Heart shape outline
        ctx.beginPath()
        ctx.moveTo(centerX, centerY + 10)
        for (let i = 0; i < 8; i++) {
          const angle = (i / 8) * Math.PI * 2
          const r = 15 + Math.sin(crystalTime + i * 0.5) * 5
          const x = centerX + Math.cos(angle) * r
          const y = centerY + 15 + Math.sin(angle) * r
          if (i === 0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        }
        ctx.closePath()
        ctx.stroke()
        // Vein glow
        for (let i = 0; i < 4; i++) {
          const angle = (i / 4) * Math.PI * 2
          const endX = centerX + Math.cos(angle) * 30
          const endY = centerY + 15 + Math.sin(angle) * 30
          ctx.strokeStyle = `rgba(16, 185, 129, ${crystalAlpha * 0.5})`
          ctx.lineWidth = 1
          ctx.beginPath()
          ctx.moveTo(centerX, centerY + 15)
          ctx.lineTo(endX, endY)
          ctx.stroke()
        }
      }

      animationRef.current = requestAnimationFrame(animate)
    }

    animationRef.current = requestAnimationFrame(animate)

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      window.removeEventListener('resize', resize)
    }
  }, [equippedAddons, form])

  return <canvas ref={canvasRef} className="w-full h-96 rounded-lg border border-slate-700/50 bg-gradient-to-br from-slate-950 to-black" />
}

export default function AuraliaAddonShowcase() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [equippedAddons, setEquippedAddons] = useState(['BK-RD-phoenix-001', 'CO-YL-familiar-001'])
  const [isAutoPlay, setIsAutoPlay] = useState(true)
  const autoplayRef = useRef(null)

  const current = ADDON_ITEMS[currentIndex]
  const band = BANDS[current.band]

  useEffect(() => {
    if (!isAutoPlay) {
      if (autoplayRef.current) clearInterval(autoplayRef.current)
      return
    }

    autoplayRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % ADDON_ITEMS.length)
    }, 5000)

    return () => {
      if (autoplayRef.current) clearInterval(autoplayRef.current)
    }
  }, [isAutoPlay])

  const toggleEquip = () => {
    setEquippedAddons((prev) => {
      if (prev.includes(current.id)) {
        return prev.filter((id) => id !== current.id)
      } else {
        return [...prev, current.id]
      }
    })
  }

  const goNext = () => {
    setCurrentIndex((prev) => (prev + 1) % ADDON_ITEMS.length)
    setIsAutoPlay(false)
  }

  const goPrev = () => {
    setCurrentIndex((prev) => (prev - 1 + ADDON_ITEMS.length) % ADDON_ITEMS.length)
    setIsAutoPlay(false)
  }

  const isEquipped = equippedAddons.includes(current.id)

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-black text-slate-100">
      <div className="border-b border-slate-800/50 bg-gradient-to-b from-slate-900/50 to-transparent px-6 py-8">
        <div className="mx-auto max-w-6xl">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="h-8 w-8 text-amber-400" />
            <h1 className="text-4xl font-light tracking-wider">AURALIA ADDON SHOWCASE</h1>
          </div>
          <p className="text-sm text-slate-400">
            Watch Auralia transform with each addon. Equip pieces to see how they change her appearance in real-time.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-6 py-12 space-y-12">
        {/* Main Showcase */}
        <div className="rounded-lg border border-slate-700/50 bg-slate-900/40 p-6">
          <h2 className="mb-4 text-sm font-bold uppercase tracking-wider text-slate-300">Live Rendering</h2>
          <AuraliaCanvas equippedAddons={equippedAddons} />

          {/* Addon Info & Control */}
          <div className="mt-6 space-y-4">
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              <div>
                <p className="text-xs text-slate-400 uppercase">Current</p>
                <p className="font-light text-lg text-slate-100">{current.name}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase">Type</p>
                <p className="font-mono text-sm text-slate-300">{current.type}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase">Band</p>
                <p style={{ color: band.color }} className="font-bold">
                  {band.name}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase">Rarity</p>
                <p className="font-mono text-sm text-amber-300">{current.rarity}</p>
              </div>
            </div>

            {/* Controls */}
            <div className="flex gap-4">
              <button
                onClick={goPrev}
                className="flex items-center gap-2 rounded border border-slate-600/50 bg-slate-800/50 px-4 py-2 text-sm transition hover:bg-slate-700/50"
              >
                <ChevronLeft className="h-4 w-4" />
                Prev
              </button>
              <button
                onClick={toggleEquip}
                className={`flex-1 rounded py-2 text-sm font-bold transition ${
                  isEquipped ? 'bg-emerald-600 text-white hover:bg-emerald-500' : 'bg-amber-500 text-black hover:bg-amber-400'
                }`}
              >
                {isEquipped ? '✓ Equipped' : 'Equip Addon'}
              </button>
              <button
                onClick={goNext}
                className="flex items-center gap-2 rounded border border-slate-600/50 bg-slate-800/50 px-4 py-2 text-sm transition hover:bg-slate-700/50"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

            {/* Indicator Dots */}
            <div className="flex justify-center gap-2">
              {ADDON_ITEMS.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setCurrentIndex(idx)
                    setIsAutoPlay(false)
                  }}
                  className={`h-2 rounded-full transition ${idx === currentIndex ? 'w-8 bg-amber-500' : 'w-2 bg-slate-600'}`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Equipped Addons Display */}
        {equippedAddons.length > 0 && (
          <div className="rounded-lg border border-slate-700/50 bg-slate-900/40 p-6">
            <h3 className="mb-4 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-300">
              <Zap className="h-4 w-4 text-amber-400" />
              Currently Equipped ({equippedAddons.length})
            </h3>
            <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
              {equippedAddons.map((id) => {
                const addon = ADDON_ITEMS.find((a) => a.id === id)
                if (!addon) return null
                const aBand = BANDS[addon.band]
                return (
                  <div key={id} className="rounded border border-slate-700/30 bg-slate-800/50 p-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-sm font-light text-slate-100">{addon.name}</p>
                        <p className="mt-1 text-xs text-slate-400">{addon.type}</p>
                      </div>
                      <button
                        onClick={() => setEquippedAddons((prev) => prev.filter((aid) => aid !== id))}
                        className="text-xs text-slate-400 transition hover:text-slate-100"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="mt-2 pt-2 border-t border-slate-700/30 flex justify-between items-center">
                      <span
                        className="inline-block text-xs font-bold text-black px-2 py-1 rounded"
                        style={{ backgroundColor: aBand.color }}
                      >
                        {aBand.name}
                      </span>
                      <span className="text-xs text-amber-300 font-mono">{addon.rarity}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Full Addon Index */}
        <div className="rounded-lg border border-slate-700/50 bg-slate-900/40 p-6">
          <h3 className="mb-4 text-lg font-light tracking-wider text-slate-100">Complete Addon Index</h3>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {ADDON_ITEMS.map((addon) => {
              const aBand = BANDS[addon.band]
              const equipped = equippedAddons.includes(addon.id)
              return (
                <button
                  key={addon.id}
                  onClick={() => {
                    setCurrentIndex(ADDON_ITEMS.indexOf(addon))
                    setIsAutoPlay(false)
                  }}
                  className={`rounded-lg border p-3 transition ${
                    equipped
                      ? 'border-emerald-500 bg-emerald-950/40'
                      : 'border-slate-700/50 bg-slate-800/30 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="text-2xl mb-2">{addon.emoji}</div>
                  <p className="text-sm font-light text-left text-slate-100">{addon.name}</p>
                  <p className="mt-1 text-xs text-left text-slate-400">{addon.type}</p>
                  <div className="mt-2 pt-2 border-t border-slate-700/30 flex justify-between items-center">
                    <span
                      className="text-xs font-bold text-black px-1.5 py-0.5 rounded"
                      style={{ backgroundColor: aBand.color }}
                    >
                      {aBand.name}
                    </span>
                    <span className="text-xs text-slate-400">{addon.rarity}</span>
                  </div>
                </button>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
