'use client'

import React, { useState, useEffect, useRef } from 'react'
import { ChevronLeft, ChevronRight, Sparkles, Info, Play, Pause, Volume2, VolumeX } from 'lucide-react'

// ===== ADDON CATALOG =====
const ADDON_SHOWCASE_ITEMS = [
  {
    id: 'HW-IN-chronoshift-001',
    name: 'Chrono-Shift Goggles',
    type: 'HEADWEAR',
    band: 'INDIGO',
    rarity: 'Legendary',
    price: 2400,
    emoji: '⏱️',
    description: 'Goggles that warp temporal perception. Twin-lens design with time-offset clarity.',
    fullDescription: 'The Chrono-Shift Goggles allow the wearer to perceive moments slightly offset from reality. Twin lenses create a disorienting yet profound effect—you see echoes of the past overlaid on the present. Worn by architects of temporal ceremony.',
    tags: ['Temporal', 'Phase', 'Artifact'],
    color: '#6b46c1',
    motion: 'Shimmer + subtle echo duplication',
    visualTips: 'Look closely at the twin lenses—they shimmer with time-offset trails.',
    placement: 'HEADWEAR',
    compatibility: ['Resonance Amplifier', 'Seraphic Pendant Field'],
  },
  {
    id: 'AU-YL-sentience-001',
    name: 'Aura of Sentience',
    type: 'AURA',
    band: 'YELLOW',
    rarity: 'Epic',
    price: 1800,
    emoji: '✨',
    description: 'A luminous field radiating conscious awareness. Sparkles with purpose.',
    fullDescription: 'An aura that radiates active consciousness. When Auralia wears this, you can see her thinking. The field pulses with celebration, with breakthroughs, with moments of discovery. Each sparkle is a thought becoming light.',
    tags: ['Radiant', 'Sentient', 'Glow'],
    color: '#f59e0b',
    motion: 'Sparkle glints + celebration pulses',
    visualTips: 'Watch the aura pulse and sparkle around the creature\'s body.',
    placement: 'AURA',
    compatibility: ['Prism-Chime Familiar', 'Chrono-Shift Goggles'],
  },
  {
    id: 'BK-BL-starlight-001',
    name: 'Starlight Mantle',
    type: 'BACK ATTACHMENT',
    band: 'BLUE',
    rarity: 'Epic',
    price: 1900,
    emoji: '🌙',
    description: 'A flowing cloak of starlit mist. Drifts with cosmic grace.',
    fullDescription: 'A cloak woven from the breath of the Flow streams. It trails starlight and drifts without weight, responding to movement with graceful lag. Auralia looks like she\'s moving through a cosmic dream when wearing this.',
    tags: ['Flow', 'Cosmic', 'Drift'],
    color: '#3b82f6',
    motion: 'Float drift + ribbon sway',
    visualTips: 'See how the mantle trails behind and floats independently of movement.',
    placement: 'BACK_ATTACHMENT',
    compatibility: ['Dream Weaver Circlet', 'Echoing Void Orb'],
  },
  {
    id: 'BK-RD-phoenix-001',
    name: 'Phoenix Wings',
    type: 'BACK ATTACHMENT',
    band: 'RED',
    rarity: 'Legendary',
    price: 2200,
    emoji: '🔥',
    description: 'Wings of pure impact. Burst with recoil when unfurled.',
    fullDescription: 'Wings that feel like fire itself. When Auralia takes flight, they burst outward with impact. The shockwave is visible. This is ascendance incarnate.',
    tags: ['Impact', 'Mythic', 'Ascension'],
    color: '#ef4444',
    motion: 'Pulse bursts + shock rings',
    visualTips: 'Watch for the explosive burst when the wings unfurl.',
    placement: 'BACK_ATTACHMENT',
    compatibility: ['Resonance Amplifier', 'Seraphic Pendant Field'],
  },
  {
    id: 'CO-YL-familiar-001',
    name: 'Prism-Chime Familiar',
    type: 'COMPANION',
    band: 'YELLOW',
    rarity: 'Legendary',
    price: 2100,
    emoji: '🔮',
    description: 'A tiny familiar made of light. Speaks in glints and tones.',
    fullDescription: 'A companion made entirely of light and prism crystal. It hovers near Auralia and celebrates every moment with chimes and sparkles. When the familiar appears, you know Auralia is in good spirits.',
    tags: ['Radiant', 'Sacred', 'Crystal'],
    color: '#fbbf24',
    motion: 'Sparkle flicker + glint sweeps',
    visualTips: 'Notice the companion hovering near Auralia, sparkling with life.',
    placement: 'COMPANION',
    compatibility: ['Aura of Sentience', 'Chrono-Shift Goggles'],
  },
  {
    id: 'BW-GN-crystalheart-001',
    name: 'Crystal Heart Harness',
    type: 'BODYWEAR',
    band: 'GREEN',
    rarity: 'Rare',
    price: 1400,
    emoji: '💎',
    description: 'Living crystalline harness that breathes and blooms.',
    fullDescription: 'A living harness that grows with Auralia. It pulses like a heartbeat, veins illuminating in cascades. The crystalline structure unfurls as she moves, showing growth and regeneration in motion.',
    tags: ['Growth', 'Crystalline', 'Heart'],
    color: '#10b981',
    motion: 'Slow pulse breathing + unfurl reveals',
    visualTips: 'See the veins pulse with life across Auralia\'s torso.',
    placement: 'BODYWEAR',
    compatibility: ['Starlight Mantle', 'Echoing Void Orb'],
  },
  {
    id: 'CO-IN-echovoid-001',
    name: 'Echoing Void Orb',
    type: 'COMPANION',
    band: 'INDIGO',
    rarity: 'Rare',
    price: 1500,
    emoji: '◯',
    description: 'A temporal companion that listens for cracks in time.',
    fullDescription: 'A small orb that floats near Auralia, always slightly out of sync with reality. Its rings expand and echo, creating a temporal aura. The Atelier uses these to listen for instability in time streams.',
    tags: ['Echo', 'Time', 'Familiar'],
    color: '#6b46c1',
    motion: 'Time-offset pulses + delayed rings',
    visualTips: 'Watch for the delayed echo rings expanding around the orb.',
    placement: 'COMPANION',
    compatibility: ['Chrono-Shift Goggles', 'Starlight Mantle'],
  },
]

const BANDS = {
  RED: { name: 'Impact', color: '#ef4444', desc: 'Bursts, shockwaves, recoil, slam pulses' },
  ORANGE: { name: 'Kinetic', color: '#ff6b35', desc: 'Spins, whips, accelerations, streak arcs' },
  YELLOW: { name: 'Radiant', color: '#f59e0b', desc: 'Sparkle, glints, crackle flicker' },
  GREEN: { name: 'Growth', color: '#10b981', desc: 'Unfurling, breathing bloom, expansion loops' },
  BLUE: { name: 'Flow', color: '#3b82f6', desc: 'Drift, wave motion, ripples, mist currents' },
  INDIGO: { name: 'Phase', color: '#6b46c1', desc: 'Warps, echoes, time offsets, lensing' },
  PURPLE: { name: 'Transcendent', color: '#a855f7', desc: 'Ceremonial unfolding, sacred rotation' },
}

function RotatingShowcase() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlay, setIsAutoPlay] = useState(true)
  const [isAudioEnabled, setIsAudioEnabled] = useState(true)
  const autoplayInterval = useRef(null)

  useEffect(() => {
    if (!isAutoPlay) {
      if (autoplayInterval.current) clearInterval(autoplayInterval.current)
      return
    }

    autoplayInterval.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % ADDON_SHOWCASE_ITEMS.length)
    }, 6000)

    return () => {
      if (autoplayInterval.current) clearInterval(autoplayInterval.current)
    }
  }, [isAutoPlay])

  const current = ADDON_SHOWCASE_ITEMS[currentIndex]
  const band = BANDS[current.band]

  const goNext = () => {
    setCurrentIndex((prev) => (prev + 1) % ADDON_SHOWCASE_ITEMS.length)
    setIsAutoPlay(false)
  }

  const goPrev = () => {
    setCurrentIndex((prev) => (prev - 1 + ADDON_SHOWCASE_ITEMS.length) % ADDON_SHOWCASE_ITEMS.length)
    setIsAutoPlay(false)
  }

  return (
    <div className="relative w-full max-w-6xl mx-auto">
      {/* Main Showcase */}
      <div className="relative overflow-hidden rounded-lg border border-slate-700/50 bg-gradient-to-br from-slate-900/80 to-slate-950/95 shadow-2xl">
        <div className="relative h-96 flex items-center justify-center overflow-hidden">
          {/* Background glow */}
          <div className="absolute inset-0 opacity-20" style={{ background: `radial-gradient(circle at center, ${current.color}44, transparent 70%)` }} />

          {/* Animated background */}
          <div className="absolute inset-0">
            <svg className="w-full h-full" viewBox="0 0 800 400" preserveAspectRatio="xMidYMid meet">
              <defs>
                <radialGradient id="showcaseGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor={current.color} stopOpacity="0.15" />
                  <stop offset="100%" stopColor={current.color} stopOpacity="0" />
                </radialGradient>
              </defs>
              <circle cx="400" cy="200" r="200" fill="url(#showcaseGrad)" />
              <circle cx="400" cy="200" r="150" stroke={current.color} strokeWidth="1" fill="none" opacity="0.3" />
              <circle cx="400" cy="200" r="100" stroke={current.color} strokeWidth="1" fill="none" opacity="0.2" />
            </svg>
          </div>

          {/* Content */}
          <div className="relative z-10 flex flex-col items-center gap-4">
            <div className="text-7xl animate-pulse">{current.emoji}</div>
            <h2 className="text-2xl font-light tracking-wider text-slate-100">{current.name}</h2>
            <div
              className="inline-block rounded px-3 py-1 text-xs font-bold text-black"
              style={{ backgroundColor: current.color }}
            >
              {band.name} • {current.rarity}
            </div>
          </div>
        </div>

        {/* Details Section */}
        <div className="border-t border-slate-700/50 bg-slate-900/60 p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            <div>
              <p className="text-xs text-slate-400 uppercase">Type</p>
              <p className="font-mono text-sm text-slate-200">{current.type}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase">Motion</p>
              <p className="font-mono text-xs text-slate-300">{current.motion}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase">Price</p>
              <p className="font-mono text-sm text-emerald-400">{current.price} MOSS</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase">ID</p>
              <p className="font-mono text-xs text-amber-300">{current.id}</p>
            </div>
          </div>

          <div className="border-t border-slate-700/50 pt-4 space-y-2">
            <p className="text-sm leading-relaxed text-slate-300">{current.fullDescription}</p>
            <p className="text-xs italic text-slate-400">{current.visualTips}</p>
          </div>

          <div className="flex flex-wrap gap-2">
            {current.tags.map((tag) => (
              <span key={tag} className="rounded-full bg-slate-800/50 px-2 py-1 text-xs text-slate-300">
                {tag}
              </span>
            ))}
          </div>

          {current.compatibility.length > 0 && (
            <div className="rounded border border-slate-700/50 bg-slate-800/30 p-3">
              <p className="text-xs font-bold text-slate-300 mb-1">SYNERGY PAIRINGS</p>
              <p className="text-xs text-slate-400">{current.compatibility.join(' • ')}</p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <div className="mt-6 flex items-center justify-between gap-4">
        <button
          onClick={goPrev}
          className="flex items-center gap-2 rounded border border-slate-600/50 bg-slate-800/50 px-4 py-2 text-sm text-slate-300 transition hover:bg-slate-700/50"
        >
          <ChevronLeft className="h-4 w-4" />
          Previous
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAutoPlay(!isAutoPlay)}
            className={`flex items-center gap-2 rounded px-3 py-2 text-xs font-bold transition ${
              isAutoPlay ? 'bg-amber-500 text-black' : 'bg-slate-800/50 text-slate-300'
            }`}
          >
            {isAutoPlay ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {isAutoPlay ? 'Pause' : 'Play'}
          </button>

          <button
            onClick={() => setIsAudioEnabled(!isAudioEnabled)}
            className={`flex items-center gap-2 rounded px-3 py-2 text-xs font-bold transition ${
              isAudioEnabled ? 'bg-slate-700 text-slate-200' : 'bg-slate-800/50 text-slate-400'
            }`}
          >
            {isAudioEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </button>
        </div>

        <button
          onClick={goNext}
          className="flex items-center gap-2 rounded border border-slate-600/50 bg-slate-800/50 px-4 py-2 text-sm text-slate-300 transition hover:bg-slate-700/50"
        >
          Next
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      {/* Indicator Dots */}
      <div className="mt-4 flex justify-center gap-2">
        {ADDON_SHOWCASE_ITEMS.map((_, idx) => (
          <button
            key={idx}
            onClick={() => {
              setCurrentIndex(idx)
              setIsAutoPlay(false)
            }}
            className={`h-2 rounded-full transition ${
              idx === currentIndex ? 'w-8 bg-amber-500' : 'w-2 bg-slate-600'
            }`}
          />
        ))}
      </div>
    </div>
  )
}

function SpectrumBandGuide() {
  return (
    <div className="rounded-lg border border-slate-800/50 bg-slate-900/30 p-6">
      <h3 className="mb-4 flex items-center gap-2 text-lg font-light tracking-wider text-slate-100">
        <Sparkles className="h-5 w-5 text-amber-400" />
        Spectrum Band Motion Grammar
      </h3>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {Object.entries(BANDS).map(([key, band]) => (
          <div key={key} className="rounded border border-slate-700/30 bg-slate-800/30 p-3">
            <div
              className="mb-2 inline-block rounded px-2 py-1 text-xs font-bold text-black"
              style={{ backgroundColor: band.color }}
            >
              {band.name}
            </div>
            <p className="text-xs leading-relaxed text-slate-400">{band.desc}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function AddonShowcaseHub() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-black text-slate-100">
      {/* Header */}
      <div className="border-b border-slate-800/50 bg-gradient-to-b from-slate-900/50 to-transparent px-6 py-8">
        <div className="mx-auto max-w-6xl">
          <div className="flex items-center gap-3 mb-4">
            <Sparkles className="h-8 w-8 text-amber-400" />
            <h1 className="text-4xl font-light tracking-wider text-slate-100">ADDON SHOWCASE</h1>
          </div>
          <p className="text-sm text-slate-400">
            Explore the canonical addon registry. See how each piece transforms the wearer. Click through to discover spectrum bands, rarities, and synergy pairings.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-6xl px-6 py-12 space-y-12">
        {/* Rotating Showcase */}
        <section>
          <RotatingShowcase />
        </section>

        {/* Spectrum Band Guide */}
        <section>
          <SpectrumBandGuide />
        </section>

        {/* Addon Grid Listing */}
        <section>
          <h3 className="mb-6 text-2xl font-light tracking-wider text-slate-100">Complete Addon Index</h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {ADDON_SHOWCASE_ITEMS.map((addon) => {
              const band = BANDS[addon.band]
              return (
                <div
                  key={addon.id}
                  className="group rounded-lg border border-slate-700/50 bg-slate-900/40 p-4 transition hover:border-slate-600 hover:bg-slate-900/60"
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="text-3xl">{addon.emoji}</div>
                    <span
                      className="inline-block rounded px-2 py-1 text-xs font-bold text-black"
                      style={{ backgroundColor: addon.color }}
                    >
                      {addon.rarity}
                    </span>
                  </div>
                  <h4 className="font-light tracking-wide text-slate-100">{addon.name}</h4>
                  <p className="mt-1 text-xs text-slate-400">{addon.description}</p>
                  <div className="mt-3 flex items-center justify-between border-t border-slate-700/30 pt-3">
                    <div className="text-xs text-slate-500">
                      <p>{addon.type}</p>
                      <p
                        className="font-bold text-white"
                        style={{ color: band.color }}
                      >
                        {band.name}
                      </p>
                    </div>
                    <div className="text-right text-xs">
                      <p className="text-slate-400">Price</p>
                      <p className="font-mono text-emerald-400">{addon.price}</p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </section>

        {/* Info Section */}
        <section className="rounded-lg border border-slate-800/50 bg-gradient-to-r from-slate-900/30 to-slate-950/50 p-6">
          <div className="grid gap-6 sm:grid-cols-2">
            <div>
              <h4 className="mb-2 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-200">
                <Sparkles className="h-4 w-4 text-amber-400" />
                Addon System
              </h4>
              <p className="text-xs leading-relaxed text-slate-400">
                Each addon is a canonical entry in the Moss60 registry. Every piece has a deterministic ID, a spectrum band assignment (motion grammar), and a rarity tier. Addons can be minted directly to your identity with zero collection fees.
              </p>
            </div>
            <div>
              <h4 className="mb-2 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-200">
                <Info className="h-4 w-4 text-cyan-400" />
                How to Mint
              </h4>
              <p className="text-xs leading-relaxed text-slate-400">
                Visit the Addon Store to browse the full catalog. Select an addon, confirm the minting ceremony (4 steps), and it will be sealed to your Jewble identity via ECDSA P-256 signature. Your addon is yours forever.
              </p>
            </div>
          </div>
        </section>

        {/* Footer */}
        <div className="border-t border-slate-800/50 pt-8 text-center">
          <p className="text-xs text-slate-500">
            Addon Showcase Hub • Built for Blue Snake Studios • {ADDON_SHOWCASE_ITEMS.length} canonical pieces
          </p>
        </div>
      </div>
    </div>
  )
}
